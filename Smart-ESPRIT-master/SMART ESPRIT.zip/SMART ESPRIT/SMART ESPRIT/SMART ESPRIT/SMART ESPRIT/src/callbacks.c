#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

int y = 1;
int x = 2;
personne n;
date dt;
int x_h;
int y_h;
char id2[10];
stock p;
int choix=0;
int x_r=1;
int y_r=1;



//////////////////////////////////////////////////////////////////////////////////
void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *windowmenu, *windowlogin;
GtkWidget *entry1,*entry2, *label39;
char log[20];
char pw[20];
int trouve;

windowlogin=lookup_widget(button,"windowlogin");
entry1 = lookup_widget (button,"entry1");
entry2 = lookup_widget (button,"entry2");
label39 = lookup_widget(button,"label39");
strcpy(n.nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(n.motdepasse,gtk_entry_get_text(GTK_ENTRY(entry2)));
strcpy(log,n.nomutilisateur);
strcpy(pw,n.motdepasse);
trouve=verif(log,pw); 

if (trouve==1)
{

windowmenu= create_windowmenu ();
gtk_widget_hide(windowlogin);
gtk_widget_show(windowmenu);
}
else
gtk_widget_show(label39);
}

////////////////////////////////////////////////////////////////////////////////////
void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{ 
int pass = 1;
GtkWidget *entry3 ,*entry4 ,*entry5, *entry7, *label38;
char text1[20];
personne n;
FILE *f=NULL;
GtkWidget *windowlogin,*output ;
GtkWidget *combobox1,*windowinscri,*ejour,*emois,*eannee;

windowinscri = lookup_widget (button,"windowinscri");
entry3 = lookup_widget (button,"entry3");
entry4 = lookup_widget(button,"entry4");
entry5 = lookup_widget(button,"entry5");
entry7 = lookup_widget(button,"entry6");
label38 = lookup_widget(button,"label38");

//output=lookup_widget(button,"");

ejour=lookup_widget (button,"jour");
emois=lookup_widget (button,"mois");
eannee=lookup_widget (button,"annee");

strcpy(n.prenom ,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(entry4)));
strcpy(n.nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry5)));
strcpy(n.motdepasse,gtk_entry_get_text(GTK_ENTRY(entry7)));

//strcpy(text1,gtk_entry_get_text(GTK_ENTRY(output)));

n.datnaissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ejour));
n.datnaissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(emois));
n.datnaissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(eannee));

combobox1 = lookup_widget(button, "combobox1") ;

if (x==1)
strcpy (n.sexe,"Femme");
else if  (x==2)
strcpy (n.sexe,"Homme");


/*if(strcmp("Admin",)==0)
strcpy(n.role,"Admin");

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Technicien");

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Nutritionniste");

else if(strcmp("Agent du Foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Agent du Foyer");

else if(strcmp("Agent du Restaurant ",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Agent du Restaurant");

else if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Etudiant");*/



if(strcmp(n.nom,"")==0 || strcmp(n.prenom,"")==0 || strcmp(n.nomutilisateur,"")==0 || strcmp(n.motdepasse,"")==0 || strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)),"")==0 ){
pass =0;
gtk_widget_show(label38);
} else 
{
if(strcmp("Agent du Foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Agent_du_Foyer");

else if(strcmp("Agent du Restaurant ",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Agent_du_Restaurant");

else
strcpy(n.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
}

if(pass == 1 ) {
f=fopen("utilisateur.txt","a+");
if (f!= NULL)
{

fprintf(f,"%s %s %s %s %s %s %d %d %d \n",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,n.datnaissance.jour,n.datnaissance.mois,n.datnaissance.annee);
fclose(f);
 
}
gtk_widget_hide(windowinscri);
windowlogin= create_windowlogin ();
gtk_widget_show(windowlogin); 
}




/*if((strcmp(n.prenom,"")==0) || (strcmp(n.nom,"")==0) || (strcmp(n.nomutilisateur,"")==0) ||  || (strcmp(n.motdepasse,"")==0)) 
{ sprintf(MESSAGE,"%s",NN);
}else {ajouter(n);
sprintf(MESSAGE,"%s",UI); }
gtk_label_set_text(GTK_LABEL(label_ajouter),MESSAGE);
*/


}



////////////////////////////////////////////////////////////////////////////////////
void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowlogin, *windowinscri;
windowlogin= create_windowlogin ();
windowinscri = lookup_widget(button,"windowinscri");
gtk_widget_hide(windowinscri);
gtk_widget_show(windowlogin);

}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *espace_tech,*windowmenu;
espace_tech= create_espace_tech ();
windowmenu = lookup_widget(button,"windowmenu");
gtk_widget_hide(windowmenu);
gtk_widget_show(espace_tech);
}

////////////////////////////////////////////////////////////////////////////////////
void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowadmin, *windowmenu;

windowmenu = lookup_widget(button,"windowmenu");
windowadmin= create_windowadmin ();
gtk_widget_hide(windowmenu);
gtk_widget_show(windowadmin);
}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Menu_du_jour,*windowmenu;
Menu_du_jour= create_Menu_du_jour();
windowmenu = lookup_widget(button,"windowmenu");
gtk_widget_show(Menu_du_jour);
gtk_widget_hide(windowmenu);
}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dashboard_hebergement,*windowmenu;
windowmenu = lookup_widget(button,"windowmenu");
dashboard_hebergement= create_dashboard_hebergement ();
gtk_widget_show(dashboard_hebergement);
gtk_widget_hide(windowmenu);
}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamation ,*windowmenu;
windowmenu = lookup_widget(button,"windowmenu");
reclamation = create_reclamation ();
gtk_widget_show(reclamation );
gtk_widget_hide(windowmenu);

}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *window_stock,*windowmenu;
windowmenu = lookup_widget(button,"windowmenu");
window_stock= create_window_stock ();
gtk_widget_show(window_stock);
gtk_widget_hide(windowmenu);
}

////////////////////////////////////////////////////////////////////////////////////
void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowlogin2, *windowmenu;

windowmenu=lookup_widget(button,"windowmenu");
windowlogin2= create_windowlogin ();
gtk_widget_hide(windowmenu);
gtk_widget_show(windowlogin2);

}

////////////////////////////////////////////////////////////////////////////////////
void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *windowmenu, *windowadmin;

windowadmin=lookup_widget(button,"windowadmin");
windowmenu= create_windowmenu ();
gtk_widget_hide(windowadmin);
gtk_widget_show(windowmenu);

}

////////////////////////////////////////////////////////////////////////////////////


void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1,*windowadmin;
windowadmin=lookup_widget(objet,"windowadmin");
treeview1=lookup_widget(windowadmin,"treeview1");
afficher_personne(treeview1);
}

////////////////////////////////////////////////////////////////////////////////////
void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry8;
char nomutilisateur[20];

    FILE*f;
    FILE*h;
     
    entry8 = lookup_widget (button,"entry8");
    strcpy(nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry8)));
   

    f=fopen("utilisateur.txt","r");
    h=fopen("test2.txt","a+");

   if(f==NULL && h==NULL)
	printf("desole");
    
    
   	 while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n ",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,&n.datnaissance.jour,&n.datnaissance.mois,&n.datnaissance.annee)!=EOF ) 
    {
        if (strcmp(nomutilisateur,n.nomutilisateur)!=0)
            {
                fprintf(h,"%s %s %s %s %s %s %d %d %d \n",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,n.datnaissance.jour,n.datnaissance.mois,n.datnaissance.annee);



            }
    }
    fclose(f);
    fclose(h);
    remove("utilisateur.txt");
    rename("test2.txt","utilisateur.txt");

}

////////////////////////////////////////////////////////////////////////////////////
void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowinscri, *windowlogin;
windowlogin = lookup_widget(button,"windowlogin");
windowinscri=create_windowinscri();
gtk_widget_hide(windowlogin);
gtk_widget_show(windowinscri);
}

////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=1;}
}

////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=2;}
}

////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}

////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}

////////////////////////////////////////////////////////////////////////////////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* prenom;
gchar* nom;
gchar* nomutilisateur;
gchar* motdepasse;
gchar* sexe;
gchar* role;
gint* jour;
gint* mois;
gint* annee;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&prenom,1,&nom,2,&nomutilisateur,3,&motdepasse,4,&sexe,5,&role,6,&jour,7,&mois,8,&annee, -1);

strcpy(n.prenom,prenom);
strcpy(n.nom,nom);
strcpy(n.nomutilisateur,nomutilisateur);
strcpy(n.motdepasse,motdepasse);
strcpy(n.sexe,sexe);
strcpy(n.role,role);
n.datnaissance.jour=jour;
n.datnaissance.mois=mois;
n.datnaissance.annee=annee;
afficher_personne(treeview);
}
afficher_personne(treeview);
}
///////////////////////////////////////////////////////////////////////////////////
void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char text2[20]="Femme";
personne n;
FILE *f=NULL;
int pass = 1;
GtkWidget *windowmenu,*windowadmin,*entry9,*entry10,*entry12,*entry11,*entry13, *label40;
GtkWidget *fjour,*fmois,*fannee;


windowadmin = lookup_widget(button,"windowadmin");
entry9 = lookup_widget (windowadmin,"entry9");
entry10 = lookup_widget(windowadmin,"entry10");
entry12 = lookup_widget(windowadmin,"entry12");
entry11 = lookup_widget(windowadmin,"entry11");
label40 = lookup_widget(windowadmin,"label40");


fjour=lookup_widget (windowadmin,"jourx");
fmois=lookup_widget (windowadmin,"moisx");
fannee=lookup_widget (windowadmin,"anneex");

strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(entry9)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(entry10)));
strcpy(n.nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry12)));
strcpy(n.motdepasse,gtk_entry_get_text(GTK_ENTRY(entry11)));


n.datnaissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(fjour));
n.datnaissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(fmois));
n.datnaissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(fannee));

GtkWidget *combobox2;
combobox2 = lookup_widget(windowadmin, "combobox2") ;

if(y==1)
	strcpy(text2,"Femme");
else if (y==2)
	strcpy(text2,"Homme");

/*if(strcmp("Admin",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Admin");

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Technicien");

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Nutritionniste");

else if(strcmp("Agent du Foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Agent_du_Foyer");

else if(strcmp("Agent du Restaurant ",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Agent_du_Restaurant");

else if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Etudiant");*/

if(strcmp(n.nom,"")==0 || strcmp(n.prenom,"")==0 || strcmp(n.nomutilisateur,"")==0 || strcmp(n.motdepasse,"")==0 || strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)),"")==0 ){
pass=0;
gtk_widget_show(label40);
}
else {
if(strcmp("Agent du Foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Agent_du_Foyer");

else if(strcmp("Agent du Restaurant ",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Agent_du_Restaurant");

else
strcpy(n.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
}
if(pass ==1)
{
f=fopen("utilisateur.txt","a+");
if (f!= NULL)
{

fprintf(f,"%s %s %s %s %s %s %d %d %d \n",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,text2,n.role,n.datnaissance.jour,n.datnaissance.mois,n.datnaissance.annee);
fclose(f);
 
}
windowmenu= create_windowmenu ();
gtk_widget_hide(windowadmin);
gtk_widget_show(windowmenu); 
}

}




void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry13;
GtkWidget *windowmenu, *windowadmin;
char nomutilisateur[20];

    FILE*f;
    FILE*g;
    
    windowadmin = lookup_widget(button,"windowadmin");
    entry13 = lookup_widget (button,"entry13");
    strcpy(nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry13)));
   

    f=fopen("utilisateur.txt","r");
    g=fopen("test3.txt","a+");

   if(f==NULL && g==NULL)
	printf("desole");
    
    
   	 while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n ",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,&n.datnaissance.jour,&n.datnaissance.mois,&n.datnaissance.annee)!=EOF ) 
    {
        if (strcmp(nomutilisateur,n.nomutilisateur)!=0)
            {
                fprintf(g,"%s %s %s %s %s %s %d %d %d \n",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,n.datnaissance.jour,n.datnaissance.mois,n.datnaissance.annee);

 

            }
    }
    fclose(f);
    fclose(g);
    remove("utilisateur.txt");
    rename("test3.txt","utilisateur.txt");

windowmenu= create_windowmenu ();
gtk_widget_hide(windowadmin);
gtk_widget_show(windowmenu); 

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_button19_e_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *entry14_e;
GtkWidget  *treeview1;
char nomutilisateur_rech[20];



treeview1=lookup_widget(objet,"treeview1");
entry14_e=lookup_widget(objet,"entry14_e");
strcpy(nomutilisateur_rech,gtk_entry_get_text(GTK_ENTRY(entry14_e)));
rech_personne (nomutilisateur_rech,treeview1);

}

//////////////////////////////////////////////////////////OMAR//////////////////////////////////////////////////////////////////////

void
on_button_menu_rechercher_o_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
    FILE* f;
    FILE* f1;
    FILE* f2;
    FILE* f3;
    FILE* f4;
    capteur c;
    int trouve1=0;
    int trouve2=0;
    int trouve3=0;
    int trouve4=0;
    int trouve5=0;
    int x;
    capteur m;
    char TYPE[50];
    char JOUR[50];
    char HEURE[50];
    char NOM[50];
    char REF[50];
    char VAL[50];
    char MESSAGE[300];

    GtkWidget *spinbutton_recherche_o;
    GtkWidget *entry_menu_recherche_o;
    GtkWidget *label_recherche_o;

    spinbutton_recherche_o = lookup_widget(button, "spinbutton_recherche_o") ;
    entry_menu_recherche_o = lookup_widget(button, "entry_menu_recherche_o") ;
    label_recherche_o = lookup_widget(button, "label_recherche_o") ;

    strcpy((m.ref),gtk_entry_get_text(GTK_ENTRY(entry_menu_recherche_o)));

    if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche_o))==1)
        x=1;
    else if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche_o))==2)
        x=2;
    else if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche_o))==3)
        x=3;
    else if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche_o))==4)
        x=4;
    else if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche_o))==5)
        x=5;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(x==1)
    {
        trouve1=0;
        f=fopen("temp.txt","r");
        if(f!=NULL)
        {
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Température");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve1=1;
                }
                if(trouve1==1)
                {
                    sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s °c.",TYPE,JOUR,HEURE,NOM,REF,VAL);
                }


                else
                {
                    strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀)");
                    printf("%s",MESSAGE);
                }


            }

            fclose(f);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche_o),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if(x==2)
    {
        trouve2=0;
        f1=fopen("debit.txt","r");
        if(f1!=NULL)
        {
            while (fscanf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Débit");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve2=1;
                }
                if(trouve2==1)
                {
                    sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s L/s.",TYPE,JOUR,HEURE,NOM,REF,VAL);
                }


                else
                {
                    strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀)");
                    printf("%s",MESSAGE);
                }


            }

            fclose(f1);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche_o),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if(x==3)
    {
        trouve3=0;
        f2=fopen("dechet.txt","r");
        if(f2!=NULL)
        {
            while (fscanf(f2,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Déchet");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve3=1;
                }
                if(trouve3==1)
                {
                    sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s g.",TYPE,JOUR,HEURE,NOM,REF,VAL);
                }


                else
                {
                    strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀)");
                    printf("%s",MESSAGE);
                }


            }

            fclose(f2);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche_o),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if(x==4)
    {
        trouve4=0;
        f3=fopen("mouve.txt","r");
        if(f3!=NULL)
        {
            while (fscanf(f3,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Mouvement");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve4=1;
                }
                if(trouve4==1)
                {
                    sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s .",TYPE,JOUR,HEURE,NOM,REF,VAL);
                }


                else
                {
                    strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀)");
                    printf("%s",MESSAGE);
                }


            }

            fclose(f3);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche_o),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if(x==5)
    {

        trouve5=0;
        f4=fopen("fumee.txt","r");
        if(f4!=NULL)
        {

            while (fscanf(f4,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Fumée");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve5=1;
                }
            }
            if(trouve5==1)
            {
                sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s .",TYPE,JOUR,HEURE,NOM,REF,VAL);
            }


            else
            {
                strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀) ");
                printf("%s",MESSAGE);
            }




            fclose(f4);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche_o),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }

}

void
on_button_ajouter_ajouter_o_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	capteur c;

    GtkWidget *entry_ajouter_jour_o;
    GtkWidget *entry_ajouter_heure_o;
    GtkWidget *entry_ajouter_nom_o;
    GtkWidget *entry_ajouter_ref_o;
    GtkWidget *entry_ajouter_valeur_o;
    GtkWidget *label_ajouter_o;

    entry_ajouter_jour_o = lookup_widget(button, "entry_ajouter_jour_o") ;
    entry_ajouter_heure_o = lookup_widget(button, "entry_ajouter_heure_o");
    entry_ajouter_nom_o = lookup_widget(button, "entry_ajouter_nom_o") ;
    entry_ajouter_ref_o = lookup_widget(button, "entry_ajouter_ref_o");
    entry_ajouter_valeur_o = lookup_widget(button, "entry_ajouter_valeur_o");
    label_ajouter_o = lookup_widget(button, "label_ajouter_o");


    strcpy((c.jour),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_jour_o)));
    strcpy((c.heure),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_heure_o)));
    strcpy((c.nom),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_nom_o)));
    strcpy((c.ref),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_ref_o)));
    strcpy((c.val),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_valeur_o)));

    char MESSAGE[300];
    char NN[150];
    char UI[150];

    strcpy(NN,"Veuillez remplir tout les champs");
    strcpy(UI,"Ajout effectuée avec succès! ヽ(•‿•)ノ");
    strcat(MESSAGE,NN);
    strcat(MESSAGE,UI);
    
    GtkWidget *combobox_ajouter_type_o;
    combobox_ajouter_type_o = lookup_widget(button, "combobox_ajouter_type_o") ;

    if(strcmp("Température",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type_o)))==0)
        (c.type)=1;
    else if(strcmp("Débit",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type_o)))==0)
        (c.type)=2;
    else if(strcmp("Déchet",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type_o)))==0)
        (c.type)=3;
    else if(strcmp("Mouvement",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type_o)))==0)
        (c.type)=4;
    else if(strcmp("Fumée",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type_o)))==0)
        (c.type)=5;
 
    if((strcmp(c.jour,"")==0) || (strcmp(c.heure,"")==0) || (strcmp(c.nom,"")==0) || (strcmp(c.ref,"")==0) || (strcmp(c.val,"")==0))
    {
        sprintf(MESSAGE,"%s",NN);
    }
    else
    {
        ajouter_o(c);
        sprintf(MESSAGE,"%s",UI);
    }
    gtk_label_set_text(GTK_LABEL(label_ajouter_o),MESSAGE);

}

void
on_button_modifier_ok_o_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
    capteur m;

    GtkWidget *entry_modifier_type_o;
    GtkWidget *entry_modifier_nom_new_o;
    GtkWidget *entry_modifier_jour_o;
    GtkWidget *entry_modifier_heure_o;
    GtkWidget *entry_modifier_ref_o;
    GtkWidget *entry_modifier_val_o;
    GtkWidget *label_modifier_o;

    entry_modifier_type_o = lookup_widget(button, "entry_modifier_type_o") ;
    entry_modifier_nom_new_o = lookup_widget(button, "entry_modifier_nom_new_o") ;
    entry_modifier_jour_o = lookup_widget(button, "entry_modifier_jour_o") ;
    entry_modifier_heure_o = lookup_widget(button, "entry_modifier_heure_o") ;
    entry_modifier_ref_o = lookup_widget(button, "entry_modifier_ref_o") ;
    entry_modifier_val_o = lookup_widget(button, "entry_modifier_val_o") ;
    label_modifier_o = lookup_widget(button, "label_modifier_o") ;

    (m.type)=gtk_entry_get_text(GTK_ENTRY((entry_modifier_type_o)));
    strcpy((m.nom),gtk_entry_get_text(GTK_ENTRY(entry_modifier_nom_new_o)));
    strcpy((m.jour),gtk_entry_get_text(GTK_ENTRY(entry_modifier_jour_o)));
    strcpy((m.heure),gtk_entry_get_text(GTK_ENTRY(entry_modifier_heure_o)));
    strcpy((m.ref),gtk_entry_get_text(GTK_ENTRY(entry_modifier_ref_o)));
    strcpy((m.val),gtk_entry_get_text(GTK_ENTRY(entry_modifier_val_o)));
//////////////////////////////////////////////////////////////////////////////////////
    char MESSAGE_M[300];
    char ui[150];
    char NN[150];

    strcpy(ui,"Modification effectuée avec succès! ヽ(•‿•)ノ");
    strcpy(NN,"Vérifier vos données");
    strcat(MESSAGE_M,ui);	
    strcat(MESSAGE_M,NN);

 int modi = modifier_o(m);

    if( modi==1 )
        sprintf(MESSAGE_M,"%s",ui);
    else
	        sprintf(MESSAGE_M,"%s",NN);

	    gtk_label_set_text(GTK_LABEL(label_modifier_o),MESSAGE_M);
//////////////////////////////////////////////////////////////////////////////////////
}



void
on_button_actualiser_o_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *treeview_o,*espace_tech;

    espace_tech=lookup_widget(button,"espace_tech");

    treeview_o = lookup_widget (button,"treeview_o");

    aff_cap_o(treeview_o);
}


void
on_treeview_o_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
    GtkTreeIter iter;
    gint* type;
    gchar* jour;
    gchar* heure;
    gchar* nom;
    gchar* ref;
    gchar* val;

    capteur c;

    GtkTreeModel *model = gtk_tree_view_get_model(treeview);

    if (gtk_tree_model_get_iter(model, &iter,path))
    {
        gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0,&type,1,&jour,2,&heure,3,&nom,4,&ref,5,&val, -1);
        c.type=type;
        strcpy((c.jour),jour);
        strcpy((c.heure),heure);
        strcpy((c.nom),nom);
        strcpy((c.ref),ref);
        strcpy((c.val),val);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}

void
on_button_supprimer_supprimer_o_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
    capteur m;
    capteur c;
    FILE *f;

    GtkWidget *entry_supprimer_ref_o;
    GtkWidget *label_supprimer_o;

    char MESSAGE[300];
    char NN[150];
    char UI[150];
    char nn[150];

    strcpy(UI,"Suppression effectuée avec succès! ヽ(•‿•)ノ");
    strcpy(nn,"Vérifier vos données");
    strcat(MESSAGE,UI);	
    strcat(MESSAGE,nn);

    entry_supprimer_ref_o = lookup_widget(button, "entry_supprimer_ref_o") ;
    label_supprimer_o = lookup_widget(button, "label_supprimer_o") ;

    strcpy((m.ref),gtk_entry_get_text(GTK_ENTRY(entry_supprimer_ref_o)));

 int supp=   supprimer_o(m);

    if( supp==1 )
        sprintf(MESSAGE,"%s",UI);
    else
	        sprintf(MESSAGE,"%s",nn);

	    gtk_label_set_text(GTK_LABEL(label_supprimer_o),MESSAGE);
}

void
on_button_info_consulter_o_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *label_info_temp_o;
    label_info_temp_o = lookup_widget(button, "label_info_temp_o") ;
    GtkWidget *label_info_debit_o;
    label_info_debit_o = lookup_widget(button, "label_info_debit_o") ;
    GtkWidget *label_info_dechet_o;
    label_info_dechet_o = lookup_widget(button, "label_info_dechet_o") ;
    GtkWidget *label_info_mouve_o;
    label_info_mouve_o = lookup_widget(button, "label_info_mouve_o") ;
    GtkWidget *label_info_fumee_o;
    label_info_fumee_o = lookup_widget(button, "label_info_fumee_o") ;

    int seuil_debit_max=30, seuil_debit_min=0, val_dechet=100;
    int seuil_temp_max=30, seuil_temp_min=10;
    char MESSAGE_TEMP[400]="";
    char MESSAGE_DEBIT[400]="";
    char MESSAGE_DECHET[400]="";
    char MESSAGE_MOUVE[400]="";
    char MESSAGE_FUMEE[400]="";
    int VAL=NULL;
    capteur c;

    FILE* f;
    FILE* f1;
    FILE* f2;
    FILE* f3;
    FILE* f4;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
   f=fopen("temp.txt","r");
    if(f!=NULL)
    {
        char MESSAGE_TEMPO[50];
        char NOM_TEMP[20];

        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {
            VAL=atoi(c.val);
            strcpy(NOM_TEMP,(c.nom));
            strcat(MESSAGE_TEMPO,NOM_TEMP);

            if((seuil_temp_max<VAL)  || (seuil_temp_min>VAL))
            {
                sprintf(MESSAGE_TEMPO,"Le capteur %s est déféctueux\n",NOM_TEMP);
                strcat(MESSAGE_TEMP,MESSAGE_TEMPO);
            }

            else
            {
                sprintf(MESSAGE_TEMPO,"Le capteur %s est stable\n",NOM_TEMP);
                strcat(MESSAGE_TEMP,MESSAGE_TEMPO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_temp_o),MESSAGE_TEMP);

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("debit.txt","r");
    if(f!=NULL)
    {
        VAL=0;
        char MESSAGE_DEBITO[50];
        char NOM_DEBIT[20];
        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {

            VAL=atoi(c.val);
            strcpy(NOM_DEBIT,(c.nom));
            strcat(MESSAGE_DEBITO,NOM_DEBIT);

            if((seuil_debit_max<VAL)  || (seuil_debit_min>VAL))
            {
                sprintf(MESSAGE_DEBITO,"Le capteur %s est déféctueux\n",NOM_DEBIT);
                strcat(MESSAGE_DEBIT,MESSAGE_DEBITO);
            }

            else
            {
                sprintf(MESSAGE_DEBITO,"Le capteur %s est stable\n",NOM_DEBIT);
                strcat(MESSAGE_DEBIT,MESSAGE_DEBITO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_debit_o),MESSAGE_DEBIT);

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("dechet.txt","r");
    if(f!=NULL)
    {
        VAL=0;
        char MESSAGE_DECHETO[100];
        char NOM_DECHET[40];
        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {

            VAL=atoi(c.val);
            strcpy(NOM_DECHET,(c.nom));
            strcat(MESSAGE_DECHETO,NOM_DECHET);

            if(val_dechet<VAL)
            {
                sprintf(MESSAGE_DECHETO,"%s a tros de déchet\n",NOM_DECHET);
                strcat(MESSAGE_DECHET,MESSAGE_DECHETO);
            }

            else
            {
                sprintf(MESSAGE_DECHETO,"Le meilleur plat appartient au %s\n",NOM_DECHET);
                strcat(MESSAGE_DECHET,MESSAGE_DECHETO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_dechet_o),MESSAGE_DECHET);

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("mouve.txt","r");
    if(f!=NULL)
    {
        VAL=0;
        char MESSAGE_MOUVEO[100];
        char NOM_MOUVE[40];
        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {

            VAL=atoi(c.val);
            strcpy(NOM_MOUVE,(c.nom));
            strcat(MESSAGE_MOUVEO,NOM_MOUVE);

            if(VAL==0)
            {
                sprintf(MESSAGE_MOUVEO,"Pas de mouvement au niveau du capteur %s\n",NOM_MOUVE);
                strcat(MESSAGE_MOUVE,MESSAGE_MOUVEO);
            }

            else
            {
                sprintf(MESSAGE_MOUVEO,"Le capteur %s détecte un mouvement\n",NOM_MOUVE);
                strcat(MESSAGE_MOUVE,MESSAGE_MOUVEO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_mouve_o),MESSAGE_MOUVE);

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("fumee.txt","r");
    if(f!=NULL)
    {
        VAL=0;
        char MESSAGE_FUMEEO[100];
        char NOM_FUMEE[40];

        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {

            VAL=atoi(c.val);
            strcpy(NOM_FUMEE,(c.nom));
            strcat(MESSAGE_FUMEEO,NOM_FUMEE);

            if(VAL==0)
            {
                sprintf(MESSAGE_FUMEEO,"Pas de fumée au niveau du capteur %s\n",NOM_FUMEE);
                strcat(MESSAGE_FUMEE,MESSAGE_FUMEEO);
            }

            else
            {
                sprintf(MESSAGE_FUMEEO,"Le capteur %s détecte un gaz\n",NOM_FUMEE);
                strcat(MESSAGE_FUMEE,MESSAGE_FUMEEO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_fumee_o),MESSAGE_FUMEE);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

void
on_button_true_actualiser_o_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *espace_tech;
    espace_tech = lookup_widget(button, "espace_tech") ;

    gtk_widget_destroy(espace_tech);
    espace_tech = create_espace_tech ();
    gtk_widget_show(espace_tech);
}
////////////////////////////////////////////////////OMAR///////////////////////////////////////////////////////////////:::


/////////////////////////////////////////////////////WASSIM//////////////////////////////////////////////////////////////
void
on_button_1_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj_hebergement, *dashboard_hebergement;


dashboard_hebergement=lookup_widget(objet,"dashboard_hebergement");

//gtk_widget_destroy(dashboard_hebergement);
aj_hebergement=lookup_widget(objet,"aj_hebergement");
aj_hebergement=create_aj_hebergement();

gtk_widget_show(aj_hebergement);
}


void
on_button_2_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod_hebergement, *dashboard_hebergement;


dashboard_hebergement=lookup_widget(objet,"dashboard_hebergement");

//gtk_widget_destroy(dashboard_hebergement);
mod_hebergement=lookup_widget(objet,"mod_hebergement");
mod_hebergement=create_mod_hebergement();

gtk_widget_show(mod_hebergement);
}


void
on_button_3_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af_hebergement, *dashboard_hebergement;


dashboard_hebergement=lookup_widget(objet,"dashboard_hebergement");

//gtk_widget_destroy(dashboard_hebergement);
af_hebergement=lookup_widget(objet,"af_hebergement");
af_hebergement=create_af_hebergement();

gtk_widget_show(af_hebergement);

treeview=lookup_widget(af_hebergement,"treeview_hebergement");

afficher_hebergement(treeview,"hebergement.txt");
}


void
on_button_4_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *pInfo, *b;
b=lookup_widget(objet,"button4");
char str[1000], ch[1000]="";
strcpy(ch,nombre_etudiant("hebergement.txt"));
sprintf(str,"%s",ch);
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,str);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}



void
on_treeview_hebergement_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gint id;
	etudiant_w e;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	e.id=id;
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer cet étudiant?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_hebergement(e,"hebergement.txt");
	afficher_hebergement(treeview,"hebergement.txt");
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
}	
}
}


void
on_button_af_w_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af_hebergement;


af_hebergement=lookup_widget(objet,"af_hebergement");

gtk_widget_destroy(af_hebergement);
af_hebergement=lookup_widget(objet,"af_hebergement");
af_hebergement=create_af_hebergement();

gtk_widget_show(af_hebergement);

treeview=lookup_widget(af_hebergement,"treeview_hebergement");

afficher_hebergement(treeview,"hebergement.txt");
}


void
on_button_mod_w_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1_w, *mod2_w, *mod3_w, *mod4_w, *mod5_w, *mod6_w, *bloc1, *bloc2, *bloc3, *pInfo;
etudiant_w e;
int c;
mod1_w=lookup_widget(objet,"mod1_w");
mod2_w=lookup_widget(objet,"mod2_w");
mod3_w=lookup_widget(objet,"mod3_w");
bloc1=lookup_widget(objet,"modA_w");
bloc2=lookup_widget(objet,"modB_w");
bloc3=lookup_widget(objet,"modC_w");
mod4_w=lookup_widget(objet,"mod4_w");
mod5_w=lookup_widget(objet,"mod5_w");
mod6_w=lookup_widget(objet,"mod6_w");
e.id=atoi(gtk_entry_get_text(GTK_ENTRY(mod1_w)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(mod2_w)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(mod3_w)));
strcpy(e.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc1))==1?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc2))==1?"B":"C");
e.chambre=gtk_combo_box_get_active(GTK_COMBO_BOX(mod4_w))+1;
e.tel=atoi(gtk_entry_get_text(GTK_ENTRY(mod5_w)));
e.niveau=gtk_combo_box_get_active(GTK_COMBO_BOX(mod6_w))+1;
modifier_hebergement(e,"hebergement.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Etudiant modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_check_id_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1_w, *mod2_w, *mod3_w, *mod4_w, *mod5_w, *mod6_w, *pInfo, *bloc1, *bloc2, *bloc3;
etudiant_w p;
int a=0;
char ch[20];
FILE *f;
mod1_w=lookup_widget(objet,"mod1_w");
mod2_w=lookup_widget(objet,"mod2_w");
mod3_w=lookup_widget(objet,"mod3_w");
bloc1=lookup_widget(objet,"modA_w");
bloc2=lookup_widget(objet,"modB_w");
bloc3=lookup_widget(objet,"modC_w");
mod4_w=lookup_widget(objet,"mod4_w");
mod5_w=lookup_widget(objet,"mod5_w");
mod6_w=lookup_widget(objet,"mod6_w");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(mod1_w)));
f = fopen("hebergement.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF)
	{
		if(p.id==id){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1){
gtk_entry_set_text(GTK_ENTRY(mod2_w),p.prenom);
gtk_entry_set_text(GTK_ENTRY(mod3_w),p.nom);
strcmp(p.bloc,"A")==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc1),TRUE):strcmp(p.bloc,"B")==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc2),TRUE):gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc3),TRUE);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod4_w),p.chambre-1);
sprintf(ch,"%d",p.tel);
gtk_entry_set_text(GTK_ENTRY(mod5_w),ch);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod6_w),p.niveau-1);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Etudiant introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *aj6, *bloc1, *bloc2, *bloc3;
GtkCalendar *ajc;
etudiant_w e;
int c;
guint day, month, year;
aj1=lookup_widget(objet,"aj1");
aj2=lookup_widget(objet,"aj2");
aj3=lookup_widget(objet,"aj3");
ajc=lookup_widget(objet,"ajc");
bloc1=lookup_widget(objet,"ajA");
bloc2=lookup_widget(objet,"ajB");
bloc3=lookup_widget(objet,"ajC");
aj4=lookup_widget(objet,"aj4");
aj5=lookup_widget(objet,"aj5");
aj6=lookup_widget(objet,"aj6");
e.id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aj1));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(aj2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(aj3)));
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
e.d.j=year;
e.d.m=month+1;
e.d.a=day;
strcpy(e.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc1))==1?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc2))==1?"B":"C");
c=gtk_combo_box_get_active(GTK_COMBO_BOX(aj4));
e.chambre = c==0?1:c==1?2:3;
e.tel=atoi(gtk_entry_get_text(GTK_ENTRY(aj5)));
e.niveau = gtk_combo_box_get_active(GTK_COMBO_BOX(aj6))+1;
ajouter_hebergement(e,"hebergement.txt");
}


void
on_button5_w_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *recherche, *dashboard_hebergement;


dashboard_hebergement=lookup_widget(objet,"dashboard_hebergement");

//gtk_widget_destroy(dashboard_hebergement);
recherche=lookup_widget(objet,"recherche");
recherche=create_recherche();

gtk_widget_show(recherche);
}


void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *r1, *r2, *r3, *r4, *r5, *r6, *r7, *r8, *pInfo;
char date_naissance[20], tel[20], niveau[20];
r1=lookup_widget(objet,"r1");
r2=lookup_widget(objet,"r2");
r3=lookup_widget(objet,"r3");
r4=lookup_widget(objet,"r4");
r5=lookup_widget(objet,"r5");
r6=lookup_widget(objet,"r6");
r7=lookup_widget(objet,"r7");
r8=lookup_widget(objet,"r8");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(r1)));
etudiant_w p = chercher_hebergement(id,"hebergement.txt");
if (p.id==-1){
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"ID introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
else{
gtk_label_set_text(GTK_LABEL(r2),p.prenom);
gtk_label_set_text(GTK_LABEL(r3),p.nom);
sprintf(date_naissance,"%d/%d/%d",p.d.j,p.d.m,p.d.a);
gtk_label_set_text(GTK_LABEL(r4),date_naissance);
gtk_label_set_text(GTK_LABEL(r5),p.bloc);
gtk_label_set_text(GTK_LABEL(r6),p.chambre==1?"Individuelle":p.chambre==2?"Double":"Triple");
sprintf(tel,"%d",p.tel);
gtk_label_set_text(GTK_LABEL(r7),tel);
sprintf(niveau,(p.niveau>0&&p.niveau<6)?(p.niveau==1?"1ère année":"%déme année"):"Non spécifié",p.niveau);
gtk_label_set_text(GTK_LABEL(r8),niveau);
}
}


void
on_supprimer_w_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sup_w, *pInfo;
etudiant_w p;
int a=0;
FILE *f;
sup_w=lookup_widget(objet,"sup_w");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(sup_w)));
f = fopen("hebergement.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF)
	{
		if(p.id==id){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1)
supprimer_hebergement(p,"hebergement.txt");
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Etudiant introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}
/////////////////////////////////////////////////////WASSIM//////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////hamza////////////////////////////////////////////////////////////




 


void
on_boutonAjouter_h_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f=NULL;
GtkWidget *ID;
GtkWidget *Al;
GtkWidget *Affichage;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
Menu menu;

char type[100]="PD";

int jour1;
int mois1;
int annee1;
char id1[20];
char al1[20];


/*if (x_h==1)
strcpy(type,"PD");
else
if (x_h==2)
strcpy(type,"Dej");
else 
if (x_h==3)
strcpy(type,"Din");*/

if (x_h==1)
strcpy(type,"PD");
else
if (x_h==2)
strcpy(type,"Dej");
else 
if (x_h==3)
strcpy(type,"Din");

jour=lookup_widget(objet_graphique,"jour_h");
mois=lookup_widget(objet_graphique,"mois_h");
annee=lookup_widget(objet_graphique,"annee_h");

ID=lookup_widget(objet_graphique,"entryID_h");
Al=lookup_widget(objet_graphique,"entryAl_h");

strcpy(id1,gtk_entry_get_text(GTK_ENTRY(ID)));
strcpy(al1,gtk_entry_get_text(GTK_ENTRY(Al)));

menu.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
menu.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
menu.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

f=fopen("menu.txt","a+");

fprintf(f,"%s %d %d %d %s %s \n",id1,menu.date.jour,menu.date.mois,menu.date.annee,al1,type);
fclose(f);


}




void
on_radiobuttonPd_h_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x_h=1;}
 
}


void
on_radiobuttonDIN_h_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x_h=3;}
}


void
on_radiobuttonDEJ_h_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x_h=2;}
}


void
on_buttonMmenu_h_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Meilleur_menu;
 Meilleur_menu = create_Meilleur_menu ();
  gtk_widget_show (Meilleur_menu);
}


void
on_buttonMj_h_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Menu_du_jour;

 Menu_du_jour = create_Menu_du_jour ();
  gtk_widget_show (Menu_du_jour);
}


void
on_buttonAj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
}


void
on_buttonAutre_h_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Autrechoix;
Autrechoix = create_Autrechoix ();
  gtk_widget_show (Autrechoix);
}


void
on_buttonAfficher_h_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Affichage;

Affichage = create_Affichage ();
gtk_widget_show (Affichage);

}


void
on_buttonSupprimer_h_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f;
FILE* f2;
Menu menu;
GtkWidget *id;
char id1[10];
f=fopen("menu.txt","r");
f2=fopen("tmp.txt","a+");
id=lookup_widget(objet_graphique,"entryIdet_h");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
if (f==NULL)
       return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id1,menu.id)!=0)
                   fprintf(f2,"%s %d %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
        }
    }
    fclose(f);
    fclose(f2);
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}


void
on_buttonModifier_h_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 FILE* f ;
 
Menu menu;

GtkWidget *id;
GtkWidget *Menu_du_jour;
GtkWidget *Modif;
id=lookup_widget(objet_graphique,"entryIdet_h");

strcpy(id2,gtk_entry_get_text(GTK_ENTRY(id)));
    f=fopen("menu.txt","r");

        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id2,menu.id)==0)
                {
		   Modif = create_Modif ();
                   gtk_widget_show (Modif);
		   

		      
		}
		else
                   { 
		  
		Menu_du_jour = create_Menu_du_jour ();
                    gtk_widget_show (Menu_du_jour);
		
		
}
		    
        }
    
    fclose(f);
}


void
on_buttonRecherche_h_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f ;
Menu menu;
GtkWidget *id;
GtkWidget *output;
char id1[10];
char texte1[20];
 int rech=0;

id=lookup_widget(objet_graphique,"entryIdet_h");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
    f=fopen("menu.txt","r");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id1,menu.id)==0)
		{
		        sprintf(texte1," aliment: %s\n",menu.aliment);
		        
                        output=lookup_widget(objet_graphique,"labelidet");
                        gtk_label_set_text(GTK_LABEL(output),texte1);
                        
			rech=1;
		}
        }
}
fclose(f);
    if (rech==0)
printf("Impossible de trouver ce menu");    

}


void
on_buttonOk_h_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f;
FILE* f2;
GtkWidget *ID;
GtkWidget *id;
GtkWidget *Al;
GtkWidget *Affichage;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
Menu menu;
Menu m;


char type[10]="PD";
int jour1;
int mois1;
int annee1;

char al1[10];

if (y_h==1)
strcpy(type,"PD");
else
if (y_h==2)
strcpy(type,"Dej");
else 
if (y_h==3)
strcpy(type,"Din");


jour=lookup_widget(objet_graphique,"jour1_h");
mois=lookup_widget(objet_graphique,"mois1_h");
annee=lookup_widget(objet_graphique,"annee1_h");


Al=lookup_widget(objet_graphique,"entryalim_h");


strcpy(al1,gtk_entry_get_text(GTK_ENTRY(Al)));

menu.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
menu.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
menu.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

f=fopen("menu.txt","a+");
f2=fopen("tmp.txt","a+");
while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
{
fprintf(f2,"%s %d %d %d %s %s \n",id2,menu.date.jour,menu.date.mois,menu.date.annee,al1,type);
    fclose(f2);
    fclose(f);
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}
}


void
on_radiobutton8_h_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y_h=3;}
}


void
on_radiobutton6_h_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y_h=1;}
}


void
on_radiobutton7_h_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y_h=2;}
}





void
on_buttonAff_h_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f ;
Dechet dechet;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
char texte1[30];
char texte2[30];
char texte3[30]; 
char s[10];
char d[10];
char b[10];
f=fopen("dechet.txt","r");
while (fscanf(f,"%s %s %s ",dechet.jour,dechet.temps,dechet.valeur)!=EOF)
        {	
		strcpy(s,"41");
                if ((strcmp(s,dechet.valeur)==2)&&(strcmp("1",dechet.temps)==0))
		{       
		return s;
                        
		}
		else 
		{
		strcpy(dechet.valeur,s);
		}
		
		
		       
			sprintf(texte1," le meilleur petit dejeuner est du jour : %s\n",dechet.jour);
		       output1=lookup_widget(objet_graphique,"Petitdej_h");
                        gtk_label_set_text(GTK_LABEL(output1),texte1);
                        
		
		/*strcpy(b,"85");
		 if ((strcmp(b,dechet.valeur)==2)&&(dechet.temps==2))
		{
		        sprintf(texte2," le meilleur dejeuner est du jour : %s\n",dechet.jour);
		       output2=lookup_widget(objet_graphique,"Dejeu");
                        gtk_label_set_text(GTK_LABEL(output2),texte2);
                        
		}
		else 
		{
		strcpy(b,dechet.valeur);
		}
		strcpy(d,"72");
		 if ((strcmp(d,dechet.valeur)==2)&&(dechet.temps==3))
		{
		        sprintf(texte1," le meilleur dinner est du jour : %s\n",dechet.jour);
		       output3=lookup_widget(objet_graphique,"Dinn");
                        gtk_label_set_text(GTK_LABEL(output3),texte3);
                        
		}
		else 
		{
		strcpy(d,dechet.valeur);
		}*/

  }      
fclose(f);

}





void
on_treeview1_h_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *id;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* aliment;
	gchar* type;
	Menu menu;
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&jour,2,&mois,3,&annee,4,&aliment,5,&type,6,-1);
strcpy(menu.id,id);
strcpy(menu.date.jour,jour);
strcpy(menu.date.mois,mois);
strcpy(menu.date.annee,annee);
strcpy(menu.date.annee,annee);
strcpy(menu.aliment,aliment);
strcpy(menu.type,type);


Afficher(treeview,"menu.txt");
}
}


void
on_retour_h_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Menu_du_jour;

 Menu_du_jour = create_Menu_du_jour ();
  gtk_widget_show (Menu_du_jour);
}


void
on_buttonshow_h_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Affichage;
GtkWidget *treeview1;
Menu menu;

Affichage = lookup_widget(objet_graphique,"buttonshow_h");
treeview1=lookup_widget(Affichage,"treeview1_h");

Afficher(treeview1,"menu.txt");
}

/////////////////////////////////////////////hamza///////////////////////////////////////////

//////////////////////////////////////siwar//////////////////////////////////////////////


void
on_button1_stock_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *window_produit;
GtkWidget  *window_stock;
window_stock=lookup_widget(button, "window_stock");
window_produit=lookup_widget(button, "window_produit");
window_produit=create_window_produit();
gtk_widget_show(window_produit);
}

void
on_button4_rupture_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget  *window_sorties;
GtkWidget  *window_stock;
window_stock=lookup_widget(button, "window_stock");
window_sorties=lookup_widget(button,"window_sorties");
window_sorties=create_window_sorties();
gtk_widget_show(window_sorties);


}


void
on_button9_supprimer_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*affiche,*w1;
        gchar* aliment;
        gchar* id;
        gchar* exemple;
        p=lookup_widget(objet,"treeview1_siwar");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&exemple,1,&aliment,2,&id,-1);

 
           supprimer_siwar(id);
	w1=lookup_widget(objet,"window_affiche");
	affiche = create_window_affiche();
	gtk_widget_show (affiche);
	gtk_widget_hide (w1);

	
GtkWidget *dialog_supprimer_produit,*window_affiche;

window_affiche=lookup_widget(objet, "window_affiche");
dialog_supprimer_produit=lookup_widget(objet, "dialog_supprimer_produit");
dialog_supprimer_produit=create_dialog_supprimer_produit();
gtk_widget_show(dialog_supprimer_produit);




}}


void
on_recherche_si_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *produit_input;
GtkWidget  *treeview1_siwar;
char produit_rech[10000];



treeview1_siwar=lookup_widget(objet,"treeview1_siwar");
produit_input=lookup_widget(objet,"entry5_si");
strcpy(produit_rech,gtk_entry_get_text(GTK_ENTRY(produit_input)));
rech_produit (produit_rech,treeview1_siwar);
}


void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *n1;
n1=lookup_widget(button,"dialog_ajouter_produit");
gtk_widget_destroy(n1);

//ajout(p);//
}

void
on_quitter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_produit;
GtkWidget  *window_sorties;
GtkWidget  *window_affiche;
GtkWidget  *window_stock;
window_affiche=lookup_widget(objet, "window_affiche");
window_stock=lookup_widget(objet, "window_stock");

window_stock=create_window_stock();
gtk_widget_show(window_stock);

gtk_widget_hide (window_affiche);
gtk_widget_hide(window_sorties);
gtk_widget_hide(window_produit);
gtk_widget_hide(window_stock);
}


void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *n1;
n1=lookup_widget(button,"dialog_supprimer_produit");
gtk_widget_destroy(n1);
}



void
on_home_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_sorties;
GtkWidget  *window_stock;
window_sorties=lookup_widget(objet, "sorties");
window_stock=lookup_widget(objet, "window_stock");

window_stock=create_window_stock();
gtk_widget_show(window_stock);

gtk_widget_hide (window_sorties);
}

void
on_affiche_rupture_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{


GtkWidget  *window_sorties;

GtkWidget  *window_valider;
window_sorties=lookup_widget(objet, "window_sorties");
window_valider=lookup_widget(objet, "window_valider");
window_valider=create_window_valider();
gtk_widget_show(window_valider);
}


void
on_treeview2_rupture_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

gchar* aliment;
gchar* id;

gint* quantite;



GtkTreeModel *model =gtk_tree_view_get_model(treeview);
 if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&aliment,1,&id,2,quantite,-1);

strcpy(p.aliment,aliment);
strcpy(p.id,id);
p.quantite=quantite;

}
}


void
on_retourner_rupture_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_valider;
GtkWidget  *window_sorties;
window_valider=create_window_valider();
window_sorties=create_window_sorties ();
gtk_widget_show(window_sorties);
}


void
on_actualiser_rupture_clicked          (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget *treeview_rupture;

  GtkWidget *window_valider;


window_valider=lookup_widget(objet, "window_valider");
treeview_rupture=lookup_widget(objet,"treeview_rupture");
afficher_enfaiedh(treeview_rupture);
}


void
on_treeview1_siwar_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* exemple;
gchar* aliment;
gchar* id;

gint* quantite;

gchar*  prix;
gchar* importe;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);
 if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&exemple,1,&aliment,2,&id,3,quantite,4,&prix,5,&importe,-1);
strcpy(p.exemple,exemple);
strcpy(p.aliment,aliment);
strcpy(p.id,id);
p.quantite=quantite;
strcpy(p.prix,prix);

strcpy(p.importe,importe);

}
}






void
on_treeview_rupture_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

gchar* aliment;
gchar* id;

gint* quantite;




GtkTreeModel *model =gtk_tree_view_get_model(treeview);
 if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&aliment,1,&id,2,&quantite,-1);

strcpy(p.aliment,aliment);
strcpy(p.id,id);
p.quantite=quantite;

}
}


void
on_checkbutton2_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	choix = 1 ;
}


void
on_checkbutton3_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	choix = 0 ;
}


void
on_ajout_si_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
int b=1;
GtkWidget  *window_produit; 
 GtkWidget 
*combobox,*existe,*input8,*input2,*input4,*spinbutton1,*oui,*non,*labelchampp;
window_produit=lookup_widget(objet, "window_produit");  
char nn[150];
char MESSAGE[50];



input8=lookup_widget(objet,"entry_produit"); 
combobox=lookup_widget(objet, "combobox_si"); 
input2=lookup_widget(objet,"entry2_si"); 
spinbutton1=lookup_widget(objet,"spinbutton_quantite");
input4=lookup_widget(objet, "entry4_si"); 
oui=lookup_widget(objet,"checkbutton2_si");
non=lookup_widget(objet,"checkbutton3_si");
labelchampp=lookup_widget(objet,"label_si");
existe=lookup_widget(objet,"label_existe");




/*strcpy(nn,"il faut remplir tous les champs");
strcat(MESSAGE,nn);}
if((strcmp(p.type,"")==0) || (strcmp(p.produit,"")==0) || (strcmp(p.reference,"")==0) ||  (strcmp(p.prix,"")==0) || (strcmp(p.importe,"")==0)){
sprintf(MESSAGE,"%s",nn);

gtk_label_set_text(GTK_LABEL(label_champ),MESSAGE);
 */






strcpy(p.exemple,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));

strcpy(p.aliment,gtk_entry_get_text(GTK_ENTRY(input8)));
p.quantite=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbutton1));
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input2)));

strcpy(p.prix,gtk_entry_get_text(GTK_ENTRY(input4)));

if(choix == 1)
	{


		strcpy(p.importe," oui");
         
	}

	if(choix == 0)
	{
		strcpy(p.importe,"non");

	}

if((strcmp(p.exemple,"")==0) || (strcmp(p.aliment,"")==0)  || (strcmp(p.id,"")==0) || (p.quantite=="") || (strcmp(p.prix,"")==0) || (strcmp(p.importe,"")==0)){
		  gtk_widget_show (labelchampp);

}
else if (exist_reference(p.id)==1)
        {

	       gtk_widget_show (existe);
        }

else {
		gtk_widget_hide (existe);
		  gtk_widget_hide(labelchampp);

ajout_siwar(p);


GtkWidget *dialog_ajouter_produit;

window_produit=lookup_widget(objet, "window_produit");
dialog_ajouter_produit=lookup_widget(objet, "dialog_ajouter_produit");
dialog_ajouter_produit=create_dialog_ajouter_produit();
gtk_widget_show(dialog_ajouter_produit);
}
}


void
on_afficher_si_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_produit;
GtkWidget  *window_affiche;
GtkWidget  *treeview1_siwar;

window_produit=lookup_widget(objet, "window_produit");
window_affiche=lookup_widget(objet, "window_affiche");
window_affiche=create_window_affiche();
gtk_widget_show(window_affiche);
treeview1_siwar=lookup_widget(objet,"treeview1_siwar");
}


void
on_radiobutton2_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	choix = 0 ;
}


void
on_radiobutton1_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	choix = 1 ;
}


void
on_modifier_si_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
stock c;
GtkWidget  *window_produit; 
 GtkWidget *input5,*produit, *reference,*input6,*spinbutton2,*importe,
 *oui,*non;

        input5=lookup_widget(objet,"combobox2_si");

	produit=lookup_widget(objet,"modifier_produit");

	reference=lookup_widget(objet,"modifier_reference"); 

spinbutton2=lookup_widget(objet,"spinbutton2_quantite");

        input6=lookup_widget(objet, "modifier_prix"); 
	oui=lookup_widget(objet,"radiobutton1_si");
        non=lookup_widget(objet,"radiobutton2_si");
	     strcpy(c.exemple,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
strcpy(c.aliment,gtk_entry_get_text(GTK_ENTRY(produit)));
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(reference)));
c.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));

strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(input6)));

if(choix == 1)
	{


		strcpy(c.importe," oui");
         
	}

	if(choix == 0)
	{
		strcpy(c.importe,"non");

	}
modifier_siwar(c);
}


void
on_actualiser_si_clicked               (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_affiche;
GtkWidget  *treeview1_siwar;


window_affiche=lookup_widget(objet, "window_affiche");

treeview1_siwar=lookup_widget(objet,"treeview1_siwar");
afficher_siwar(treeview1_siwar);
}


void
on_button11_si_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_sorties;
GtkWidget  *window_produit;
GtkWidget  *window_stock;
window_produit=lookup_widget(objet, "window_produit");
window_stock=lookup_widget(objet, "window_stock");

window_stock=create_window_stock();
gtk_widget_show(window_stock);
gtk_widget_hide(window_sorties);
gtk_widget_hide(window_produit);

}


void
on_button13_si_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_sorties; 
 GtkWidget 
*combobox3,*existe,*affiche,*non,*oui,*input10,*input11,*input12,*spinbutton3,*labelinsuffisant,*dialog_rupture;
window_sorties=lookup_widget(objet, "window_sorties");  
int quantite;

input10=lookup_widget(objet,"entry6_si"); 
combobox3=lookup_widget(objet, "combobox3_si"); 
input11=lookup_widget(objet,"entry7_si"); 
spinbutton3=lookup_widget(objet,"spinbutton6_si");
labelinsuffisant=lookup_widget(objet,"label56_si");
non=lookup_widget(objet,"label61_si");


affiche=lookup_widget(objet,"affiche_rupture");
strcpy(p.exemple,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));

strcpy(p.aliment,gtk_entry_get_text(GTK_ENTRY(input10)));
p.quantite=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbutton3));
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input11)));

char id[50];
int val=0;
FILE *f3;
FILE *f2;
FILE *f;
stock c;
f3=fopen("rupture.txt","a+");
f2=fopen("produit sorties.txt","a+");
f=fopen("produit.txt","r");

 while (fscanf(f,"%s %s %s %d %s %s \n ",c.exemple,c.aliment,c.id,&(c.quantite),c.prix,c.importe)!=EOF){


 

  

 if    ( (strcmp(c.exemple,p.exemple)==0) && (strcmp(c.id,p.id)==0)){ 

       


        if ( (c.quantite>p.quantite)){
             gtk_widget_hide(affiche);
fprintf(f2,"%s %s \n",p.aliment,p.id);
 gtk_widget_hide (labelinsuffisant);
 gtk_widget_hide (non);
}



          else if ( (c.quantite==p.quantite)   )

{

	    gtk_widget_show (non);
             gtk_widget_show(affiche);
            gtk_widget_hide (labelinsuffisant);
fprintf(f2,"%s %s \n",p.aliment,p.id);
fprintf(f3,"%s %s %d \n",p.aliment,p.id,p.quantite);

}
      else if  ((c.quantite)<(p.quantite))
{
             gtk_widget_hide(affiche);
gtk_widget_show (labelinsuffisant);
 gtk_widget_hide (non);


}
    

fclose(f);

fclose(f3); 
fclose(f2);
}}
}


void
on_button12_si_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{


GtkWidget  *window_produit;
GtkWidget  *window_stock;
window_produit=create_window_produit();
window_stock=create_window_stock();
gtk_widget_show(window_stock);
}

/////////////////////////////////////////siwar///////////////////////////////////////////////////

///////////////////////////////////////rihem/////////////////////////////////////////////////////////

void
on_button_affichage_r_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *aff,*recla;
aff=create_affichage();
gtk_widget_show(aff);
recla=lookup_widget (objet_graphique,"create_reclamation");
gtk_widget_destroy(recla);

}


void
on_button_add_r_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajout;
ajout=create_add();
gtk_widget_show(ajout);
}



void
on_button_okk_r_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
reclamation r ;

GtkWidget *labelchampp,*input1,*input2,*input3,*input4,*input5,*input6,*aff;
input1=lookup_widget(objet_graphique,"entry_cin_r");
labelchampp=lookup_widget (objet_graphique , "label1_r");
input3=lookup_widget(objet_graphique,"entry_autre_r");

input4= lookup_widget (objet_graphique , "combobox1_r");
input5= lookup_widget (objet_graphique , "combobox2_r");
input6= lookup_widget (objet_graphique , "combobox3_r");

strcpy(r.CIN_r,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(r.text_reclamation,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy (r.jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy (r.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
strcpy (r.annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));



 if(y_r==1){
strcpy(r.ref_r,"1");}
else {
strcpy(r.ref_r,"2");}


if((strcmp(r.CIN_r,"")==0) || (strcmp(r.text_reclamation,"")==0)  ||  (r.jour=="") || (strcmp(r.mois,"")==0) || (strcmp(r.annee,"")==0)){
		  gtk_widget_show (labelchampp);}







 else {
if (x_r==1)


{
ajout(r);
}

GtkWidget *dialog1_r,*add;

add=lookup_widget(objet_graphique, "add");
dialog1_r=lookup_widget(objet_graphique,"dialog1_r");
dialog1_r=create_dialog1_r();
gtk_widget_show(dialog1_r);
}
}


void
on_button_returnadd_r_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *reclama;
reclama=create_reclamation();
gtk_widget_show(reclama);
}


void
on_button_supprimer_r_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *sup;
sup=create_supprimer() ;
gtk_widget_show (sup);
}




void
on_button_modifier_r_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier;

modifier=create_modifier() ;
gtk_widget_show(modifier);
}


void
on_button_sup_r_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*aff;
char ch[20];
input1=lookup_widget(objet_graphique,"entry_cin_r");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input1)));
supprimer(ch);
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_returnsup_r_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aff;
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_modf_r_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
reclamation r ;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*affichage,*aff;
input1=lookup_widget(objet_graphique,"entry_cin1_r");
input2=lookup_widget(objet_graphique,"entry_ref1_r");
input3=lookup_widget(objet_graphique,"entry_text1_r");
input4=lookup_widget(objet_graphique,"entry_jour1_r");
input5=lookup_widget(objet_graphique,"entry_mois_r");
input6=lookup_widget(objet_graphique,"entry_annee1_r");
strcpy(r.CIN_r,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.ref_r,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.text_reclamation,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(r.jour,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(r.mois,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(r.annee,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier(r);
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_returnmodif_r_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aff;
aff=create_affichage();
gtk_widget_show(aff);
}



void
on_button_aff_r_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1_r;
treeview1_r=lookup_widget(objet_graphique,"treeview1_r");
afficher_reclamation(treeview1_r);
}


void
on_button_servicereclame_r_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *sevice;
sevice=create_sevice ();
gtk_widget_show(sevice);
}


void
on_button_service_r_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*nb ,*l;
char ch[40];
int k;
k=service_reclamation();
l=lookup_widget(objet,"label4");
if (k==1)
{sprintf(ch,"hebergement");}
if (k==2)
{sprintf(ch,"restauration");}
gtk_label_set_text(GTK_LABEL(l),ch);
}


/////////////////////////////////////////////////////////////////////////////////
void
on_button_recherche_r_clicked           (GtkWidget      *objet,
                                        gpointer         user_data)

{
GtkWidget *cin_input;
GtkWidget *treeview1_r;
char CIN_recher[20];

treeview1_r=lookup_widget(objet,"treeview1_r");
cin_input=lookup_widget(objet,"entry_rihem");
strcpy(CIN_recher,gtk_entry_get_text(GTK_ENTRY(cin_input)));

recherche_CIN(CIN_recher,treeview1_r);
}

//////////////////////////////////////////////::
void
on_treeview1_r_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)


{

GtkTreeIter iter;
	GtkWidget *treeview1_r;
	gchar* CIN_r; 
	gchar* ref_r; 
	gchar* text_reclamation;  
        gchar* jour;
        gchar* mois;
	gchar* annee;
	reclamation r;
	
	FILE *f=NULL;


	GtkTreeModel *model = gtk_tree_view_get_model(treeview1_r);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{gtk_tree_model_get (GTK_LIST_STORE(model),0,&CIN_r,1,&ref_r,2,&text_reclamation,3,&jour,4,&mois,5,&annee,-1);

	strcpy(r.CIN_r,CIN_r);
	strcpy(r.ref_r,ref_r);
        strcpy(r.text_reclamation,text_reclamation);
	strcpy(r.jour,jour);
        strcpy(r.mois,mois);
        strcpy(r.annee,annee);}

	
        afficher_reclamation(treeview1_r);


}


void
on_radiobutton1_r_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y_r=1;
}


void
on_radiobutton2_r_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y_r=2;
}


void
on_checkbutton1_r_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
x_r=1;
else 
x_r=0;
}

///////////////////////////////////////rihem/////////////////////////////////////////////////////////









void
on_button199_r_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *n2;
n2=lookup_widget(button,"dialog1_r");
gtk_widget_destroy(n2);
}


void
on_affiche3_r_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aff;
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *espace_tech,*windowmenu;
windowmenu= create_windowmenu();
espace_tech = lookup_widget(button,"espace_tech");
gtk_widget_hide(espace_tech);
gtk_widget_show(windowmenu);
}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dashboard_hebergement,*windowmenu;
windowmenu= create_windowmenu();
dashboard_hebergement = lookup_widget(button,"dashboard_hebergement");
gtk_widget_show(windowmenu);
gtk_widget_hide(dashboard_hebergement);
}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Menu_du_jour,*windowmenu;
windowmenu= create_windowmenu();
Menu_du_jour = lookup_widget(button,"Menu_du_jour");
gtk_widget_show(windowmenu);
gtk_widget_hide(Menu_du_jour);
}


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamation ,*windowmenu;
reclamation = lookup_widget(button,"reclamation");
windowmenu = create_windowmenu ();
gtk_widget_show(windowmenu );
gtk_widget_hide(reclamation);

}


void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *window_stock,*windowmenu;
window_stock = lookup_widget(button,"window_stock");
windowmenu= create_windowmenu ();
gtk_widget_show(windowmenu);
gtk_widget_hide(window_stock);
}

