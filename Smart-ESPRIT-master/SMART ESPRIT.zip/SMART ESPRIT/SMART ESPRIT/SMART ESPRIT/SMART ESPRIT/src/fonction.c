#include "callbacks.h"
#include "fonction.h"
#include <stdio.h>
#include <string.h>
enum
{
Prenom,
Nom,
Nomutilisateur,
Motdepasse,
Sexe,
Role,
Jour,
Mois,
Annee,
COLUMNS
};

int verif(char log[],char pw[])
{
int trouve=-1;
FILE *f=NULL;
//char ch1[20];
//char ch2[20];
personne n;
f=fopen("utilisateur.txt","r");
if (f!=NULL)
{
/*while (fscanf(f,"%s %s \n",ch1,ch2)!=EOF)*/ while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n ",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,&n.datnaissance.jour,&n.datnaissance.mois,&n.datnaissance.annee)!=EOF ) 
{
if ((strcmp(n.nomutilisateur,log)==0)&&(strcmp(n.motdepasse,pw)==0))
trouve=1;
}
fclose(f);
}
return (trouve);
}
//////////////////////////////////////////////////////////////////////////////////
void afficher_personne(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store; 
  
char prenom[20];
char nom[20];
char nomutilisateur[20];
char motdepasse[20];
char sexe[20];
char role[20];
int jour,mois,annee;	
store = NULL;
personne n;
  FILE *f;
	
  store=gtk_tree_view_get_model(liste);

  if (store==NULL)
  {

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",Prenom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",Nom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nomutilisateur",renderer,"text",Nomutilisateur,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("motdepasse",renderer,"text",Motdepasse,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",Sexe,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("role",renderer,"text",Role,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",Jour,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",Mois,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",Annee,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

 store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

    f = fopen("utilisateur.txt","r");

    if (f==NULL)
    {
      return;
    }
    else
    
     { f = fopen("utilisateur.txt","a+");
      while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n",prenom,nom,nomutilisateur,motdepasse,sexe,role,&jour,&mois,&annee)!=EOF)
      {
        gtk_list_store_append(store, &iter);
				gtk_list_store_set(store,&iter,Prenom,prenom,Nom,nom,Nomutilisateur,nomutilisateur,Motdepasse,motdepasse,Sexe,sexe,Role,role,Jour,jour,Mois,mois,Annee,annee, -1);

      }
      fclose(f);
	
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
			  g_object_unref(store);
}
    }
}


/////////////////////////////////////////////////////////////////////////////////////////////////
void rech_personne ( char nomutilisateur_rech[20], GtkWidget *liste)

{

FILE *f;
char prenom[20];
char nom[20];
char nomutilisateur[20];
char motdepasse[20];
char sexe[20];
char role[20];
int jour,mois,annee;	
personne n;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
if (store==NULL){

renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",Prenom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",Nom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nomutilisateur",renderer,"text",Nomutilisateur,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("motdepasse",renderer,"text",Motdepasse,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",Sexe,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("role",renderer,"text",Role,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",Jour,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",Mois,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",Annee,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

}

 store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("utilisateur.txt","r");
if (f==NULL)
{
return;}
else{


f=fopen("utilisateur.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %d %d %d \n",prenom,nom,nomutilisateur,motdepasse,sexe,role,&jour,&mois,&annee)!=EOF)

{

if (strstr(prenom,nomutilisateur_rech)!=NULL||strstr(nom,nomutilisateur_rech)!=NULL||strstr(nomutilisateur,nomutilisateur_rech)!=NULL ){
    gtk_list_store_append (store,&iter);
    gtk_list_store_set(store,&iter,Prenom,prenom,Nom,nom,Nomutilisateur,nomutilisateur,Motdepasse,motdepasse,Sexe,sexe,Role,role,Jour,jour,Mois,mois,Annee,annee, -1);
}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);}}


///////////////////////////////////////////////////////////////OMAR////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

enum
{
    TYPE,
    JOUR,
    HEURE,
    NOM,
    REF,
    VAL,
    COLUMNS_o
};

void aff_cap_o (GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

    int  type;
    char jour[20];
    char heure[20];
    char nom[20];
    char ref[20];
    char val[20];
    store = NULL;

    FILE *f;

    store=gtk_tree_view_get_model(liste);

    if (store==NULL)
    {

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("heure",renderer,"text",HEURE,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("ref",renderer,"text",REF,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("val",renderer,"text",VAL,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        store=gtk_list_store_new(COLUMNS_o,G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

        f = fopen("temp.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("temp.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
        }

        f = fopen("debit.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("debit.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
        }
        f = fopen("dechet.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("dechet.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
        }
        f = fopen("mouve.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("mouve.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
        }
        f = fopen("fumee.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("fumee.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);
        }
    }

}

/////////les fonctions/////////// 

void ajouter_o(capteur c)
{

    FILE* f;


    if ((c.type)==1)
    {
        f=fopen("temp.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val));
            fclose(f);
        }
        else printf("\n ERROR!!");
    }


    if ((c.type)==2)
    {
        f=fopen("debit.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );
            fclose(f);
        }
        else printf("\n ERROR!!");
    }

    if ((c.type)==3)
    {
        f=fopen("dechet.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );
            fclose(f);
        }
        else printf("\n ERROR!!");
    }

    if ((c.type)==4)
    {
        f=fopen("mouve.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );
            fclose(f);
        }
        else printf("\n ERROR!!");
    }

    if ((c.type)==5)
    {
        f=fopen("fumee.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );
            fclose(f);
        }
        else printf("\n ERROR!!");
    }
}
//////////////////////////////////////////////////////////////////////////////

int modifier_o(capteur m)
{
    FILE* f;
    FILE* f1;
    capteur c;
    int modi=0;
///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("temp.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {

            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==1) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );




            }
            remove("temp.txt");
            rename("replace.txt","temp.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");
///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("debit.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==2) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("debit.txt");
            rename("replace.txt","debit.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    f=fopen("dechet.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==3) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("dechet.txt");
            rename("replace.txt","dechet.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");
///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("mouve.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==4) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("mouve.txt");
            rename("replace.txt","mouve.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");
///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("fumee.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==5) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("fumee.txt");
            rename("replace.txt","fumee.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////
return modi;
}

int supprimer_o(capteur m)
{
    FILE* f;
    FILE* f1;
    capteur c;
    int supp=0;

///////////////////////////////////////////////////////////////////////////////////////////////////////

   f=fopen("temp.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );

            }
            remove("temp.txt");
            rename("replace.txt","temp.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");


        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("debit.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;

                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );


            }
            remove("debit.txt");
            rename("replace.txt","debit.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("dechet.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {



            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;

                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("dechet.txt");
            rename("replace.txt","dechet.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("mouve.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;

                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );


            }
            remove("mouve.txt");
            rename("replace.txt","mouve.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("fumee.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;

                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );


            }
            remove("fumee.txt");
            rename("replace.txt","fumee.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////
return supp;
}
///////////////////////////////////////////////////////////////OMAR////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////WASSIM//////////////////////////////////////////////////////:::
enum
{
	CIN,
	NOM_COMPLET,
	DATE_NAISSANCE,
	BLOC,
	CHAMBRE,
	TEL,
	NIVEAU,
	COLUMNS_w
};


void ajouter_hebergement(etudiant_w e, char *fname){
GtkWidget *pQuestion, *pInfo;
FILE *f;
int b=0;
gpointer user_data;
etudiant_w p;
f=fopen(fname,"a+");
if(f!=NULL)
{	while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF)
	{	
		if(e.id==p.id)
		b++;
	}
	if(b==0){
	fprintf(f,"%d %s %s %d %d %d %s %d %d %d\n",e.id,e.prenom,e.nom,e.d.j,e.d.m,e.d.a,e.bloc,e.chambre,e.tel,e.niveau);
	pQuestion=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Etudiant ajouté avec succès !");
	switch(gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pQuestion);
	break;
	}
	}
	if(b!=0){
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,"Etudiant déja existant !");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
	fclose(f);
}
}

void modifier_hebergement(etudiant_w e, char *fname){
etudiant_w p;
GtkWidget *pInfo;
gpointer user_data;
FILE *f, *g;
f=fopen(fname,"r");
g=fopen("dump.txt","w");
if(f==NULL||g==NULL)
{
	return;
}
else{
	while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF)
	{
		if(p.id!=e.id)
			fprintf(g,"%d %s %s %d %d %d %s %d %d %d\n",p.id,p.prenom,p.nom,p.d.j,p.d.m,p.d.a,p.bloc,p.chambre,p.tel,p.niveau);
		else
			fprintf(g,"%d %s %s %d %d %d %s %d %d %d\n",p.id,e.prenom,e.nom,p.d.j,p.d.m,p.d.a,e.bloc,e.chambre,e.tel,e.niveau);
	}
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Etudiant modifié avec succès !");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	fclose(f);
	fclose(g);
remove(fname);
rename("dump.txt",fname);
}
}

void afficher_hebergement(GtkWidget *liste, char *fname)
{
etudiant_w p;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
gchar date_naissance[50], nom_complet[50], chambre[20], niveau[20];
FILE *f;


store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" CIN", renderer,"text",CIN, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Nom complet", renderer,"text",NOM_COMPLET, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_resizable(column,TRUE);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Date de naissance", renderer,"text",DATE_NAISSANCE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Chambre", renderer,"text",CHAMBRE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Bloc", renderer,"text",BLOC, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Tel", renderer,"text",TEL, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Niveau", renderer,"text",NIVEAU, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);


store=gtk_list_store_new(COLUMNS_w, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING);
f=fopen(fname,"r");
if(f!=NULL)

{ f = fopen(fname,"a+");
		while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF)
	{
sprintf(niveau,(p.niveau>0&&p.niveau<6)?(p.niveau==1?"1ère année":"%déme année"):"Non spécifié",p.niveau);
sprintf(date_naissance,"%d/%d/%d",p.d.j,p.d.m,p.d.a);
sprintf(chambre,p.chambre==1?"Individuelle":p.chambre==2?"Double":"Triple");
sprintf(nom_complet,"%s %s",p.prenom, p.nom);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,CIN,p.id,NOM_COMPLET,nom_complet,DATE_NAISSANCE,date_naissance,BLOC,p.bloc,CHAMBRE,chambre,TEL,p.tel,NIVEAU,niveau,-1);
	}
	fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void supprimer_hebergement(etudiant_w e, char *fname)
{
etudiant_w p;
GtkWidget *pInfo;
gpointer user_data;
FILE *f, *g;
f=fopen(fname,"r");
g=fopen("dump.txt","w");
if(f!=NULL&&g!=NULL){
	while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF)
	{
		if(p.id!=e.id)
			fprintf(g,"%d %s %s %d %d %d %s %d %d %d\n",p.id,p.prenom,p.nom,p.d.j,p.d.m,p.d.a,p.bloc,p.chambre,p.tel,p.niveau);
	}
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Etudiant supprimé avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	fclose(f);
	fclose(g);
remove(fname);
rename("dump.txt",fname);
}
}


etudiant_w chercher_hebergement(int id, char *fname){
etudiant_w p, e;
FILE *f;
f=fopen(fname,"r");
if(f!=NULL){
	while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF)
	{
		if(p.id==id)
			return p;
	}
	fclose(f);
}
e.id=-1;
return e;
}

char* nombre_etudiant(char *fname){
    etudiant_w p;
    int a=0, b=0, c=0, d=0, e=0;
    char* ch = (char*) malloc(1000);
    FILE *f = fopen(fname,"r");
    if(f!=NULL){
        while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF){
                if(p.niveau>0&&p.niveau<6){
			switch(p.niveau){
			case 1:
			a++;
			break;
			case 2:
			b++;
			break;
			case 3:
			c++;
			break;
			case 4:
			d++;
			break;
			case 5:
			e++;
			break;
			}
		}
		else
			continue;
        }
        fclose(f);
    }
    sprintf(ch,"1ère année : %d étudiants\n2éme année : %d étudiants\n3éme année : %d étudiants\n4éme année : %d étudiants\n5éme année : %d étudiants\n",a,b,c,d,e);
return ch;
    }

//////////////////////////////////////////////////////WASSIM//////////////////////////////////////////////////////



///////////////////////////////////////////////////HAMZA///////////////////////////////////////////////////////



enum
{	
	EIDH,
	EJOUR,
	EMOIS,
	EANNEE,
	EAL,
	ETYPE,
	COLUMNS_h,
};


void Ajouter(Menu menu)
{
    FILE* f;
    f=fopen("menu.txt","a+");
    fprintf(f,"%s %d  %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
    fclose(f);
}
//////////////////////////////////////////////////////////////////
void Supprimer(char id[10],Menu menu)
{
    FILE* f ;
    FILE* f2;
    f=fopen("menu.txt","r");
    f2=fopen("tmp.txt","a+");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id,menu.id)!=0)
                   fprintf(f2,"%s %d  %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
        }
    }
    fclose(f);
    fclose(f2);
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}
////////////////////////////////////////////////////////////////////////////
void Modifier(char id[10],Menu menu)
{
    FILE* f ;
    FILE* f2;
    f=fopen("menu.txt","r+");
    f2=fopen("tmp.txt","a+");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id,menu.id)==0)
                {
		   fprintf(f2,"%s %d %d %d %s %s ",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
    
		}
		else
		    fprintf(f2,"%s %d %d %d %s %s ",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
        }
    }
    fclose(f);
    fclose(f2);
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}
//////////////////////////////////////////////////////////////////////////////
void Chercher(char id[10],Menu menu)
{
    
    FILE* f ;
    int rech=0;
    f=fopen("menu.txt","r");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id,menu.id)==0)
		{
		       rech=1;
		}
        }
    }
    fclose(f);
    if (rech==0)
    printf("Impossible de trouver cet stock\n");
}
////////////////////////////////////////////////////////////////////////////
void Afficher(GtkWidget *liste,char ch[50])
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter   iter; 
	GtkListStore  *store;
	FILE *f;
	store=NULL;
	Menu menu;
	store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EIDH,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" aliment",renderer,"text",EAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
store=gtk_list_store_new(COLUMNS_h,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen(ch,"r");
if(f==NULL)
{
return;
}
else
{
	f=fopen(ch,"a+");
	while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EIDH,menu.id,EJOUR,menu.date.jour,EMOIS,menu.date.mois,EANNEE,menu.date.annee,EAL,menu.aliment,ETYPE,menu.type,-1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
        

}

//////////////////////////////////////////////////////HAMZA/////////////////////////////////////////////////////


/////////////////////////////////////////////////siwar////////////////////////////////////////////////////////////





enum
{
EEXEMPLE,
EALIMENT,
EID,
EQUANTITE,
EPRIX,
EIMPORTE,
COLUMNS_S,
};
enum 
{
EALIMENTS,
EIDE,
EQUANTITEE,
COLUMN,
};


void ajout_siwar(stock p)

{
stock c;

FILE *f;

f=fopen("produit.txt","a+");
if(f!=NULL){

fprintf(f," %s %s %s %d %s %s \n",p.exemple,p.aliment,p.id,p.quantite,p.prix,p.importe);

fclose (f);
}
}
//////supprimer////
void supprimer_siwar(char id[50])
{

char aliment[50];
FILE*f=NULL;

FILE*f1=NULL;
 stock p;

f=fopen("produit.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %s %d %s %s \n " ,p.exemple,p.aliment,p.id,&(p.quantite),p.prix,p.importe)!=EOF)
{

if((strcmp(aliment,p.aliment)!=0) && strcmp(id,p.id)!=0)
{
fprintf(f1,"%s %s %s %d %s %s \n",p.exemple,p.aliment,p.id,p.quantite,p.prix,p.importe);
}

 }

fclose(f);
fclose(f1);

remove("produit.txt");
rename("ancien.txt","produit.txt");

}









void afficher_siwar (GtkWidget *liste)

{
FILE *f,*g;
char exemple [20];
char aliment [20];
char id [20];
int quantite;
char prix [20];
char importe[20];
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
if (store==NULL){

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",EEXEMPLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("produit",renderer,"text",EALIMENT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("reference",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("importe",renderer,"text",EIMPORTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);}

store=gtk_list_store_new (COLUMNS_S,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("produit.txt","r");
if (f==NULL)
{
return;}
else{


f=fopen("produit.txt","a+");
while (fscanf(f,"%s %s %s %d %s %s",exemple,aliment,id,&(quantite),prix,importe)!=EOF)
{
    gtk_list_store_append (store,&iter);
     gtk_list_store_set (store,&iter,EEXEMPLE,exemple,EALIMENT,aliment,EID,id,EQUANTITE,quantite,EPRIX,prix,EIMPORTE,importe,-1);
}
fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}}






/////rechercher
void rech_produit ( char produit_rech[1000], GtkWidget *liste)

{
stock p;
FILE *f,*g;
char exemple [20];
char aliment [20];
char id [20];
int quantite;
char prix [20];
char importe[20];
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
if (store==NULL){

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",EEXEMPLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("produit",renderer,"text",EALIMENT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("reference",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("importe",renderer,"text",EIMPORTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);}

store=gtk_list_store_new (COLUMNS_S,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("produit.txt","r");
if (f==NULL)
{
return;}
else{


f=fopen("produit.txt","a+");
while (fscanf(f,"%s %s %s %d %s %s",exemple,aliment,id,&(quantite),prix,importe)!=EOF)

{

if (strstr(aliment,produit_rech)!=NULL||strstr(id,produit_rech)!=NULL||strstr(prix,produit_rech)!=NULL ){
    gtk_list_store_append (store,&iter);
     gtk_list_store_set (store,&iter,EEXEMPLE,exemple,EALIMENT,aliment,EID,id,EQUANTITE,quantite,EPRIX,prix,EIMPORTE,importe,-1);
}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);}}





///////modifier_siwar
void modifier_siwar(stock c) 
{

FILE*f;
FILE*f1;
//char ch1[50],//
 stock p;

f=fopen("produit.txt","r");
f1=fopen("ancien.txt","w+");
if (f==NULL)
{printf("impo");}
else
{
while (fscanf(f,"%s %s %s %d %s %s \n ",p.exemple,p.aliment,p.id,&(p.quantite),p.prix,p.importe)!=EOF){

if( (strcmp(p.aliment,c.aliment)==0) )

fprintf(f1,"%s %s %s %d %s %s \n ",p.exemple,p.aliment,c.id,c.quantite,c.prix,c.importe);
else
fprintf(f1,"%s %s %s %d %s %s \n ",p.exemple,p.aliment,p.id,p.quantite,p.prix,p.importe);
}}
fclose(f);
fclose(f1);

remove("produit.txt");
rename("ancien.txt","produit.txt");

}
 


/////exist 
int exist_reference(char *id)
{
FILE*f=NULL;
 stock p;
f=fopen("produit.txt","r");

while (fscanf(f,"%s %s %s %d %s %s \n " ,p.exemple,p.aliment,p.id,&(p.quantite),p.prix,p.importe)!=EOF)
{
if(strcmp(p.id,id)==0)return 1;
}
fclose(f);
return 0;
}


/////exist 
int exist1_reference(char *id )
{
FILE*f=NULL;
 stock c;
f=fopen("produit.txt","r");

{
if(strcmp(c.id,id)!=0)return 1;
}
fclose(f);
return 0;

}

void afficher_enfaiedh(GtkWidget *liste)

{
FILE *f4;
char exemple [20];

char aliment [20];
char id [20];
int quantite;
char prix [20];
char importe [20];

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
if (store==NULL){



renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("aliment",renderer,"text",EALIMENTS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EIDE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



store=gtk_list_store_new (COLUMN,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_INT);
f4=fopen("rupture.txt","r");
if (f4==NULL)
{
return;}
else{


f4=fopen("rupture.txt","a+");
while (fscanf(f4,"%s %s %d ",aliment,id,&(quantite))!=EOF)
{

    gtk_list_store_append (store,&iter);
     gtk_list_store_set (store,&iter,EALIMENTS,aliment,EIDE,id,EQUANTITEE,quantite,-1);
}
fclose(f4);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}}}





















///////////////////////////////////////////////siwar//////////////////////////////////////////////////////////////

///////////////////////////////////////rihem/////////////////////////////////////////////////////////
			enum{
			cin,
			REF_r,
			RECLA,
			DAY,
			MONTH,
			YEAR,
			COLUMNS_r
			};
					/* 
 					 char CIN[20];
 				 	char text_reclamation[30];
 					 char ref;
 					 char jour; 
 			 		char mois;
  					char annee;*/
/*ajou*/
void ajout(reclamation r)
{ 
FILE*f;
f=fopen("reclamation.txt","a");
fprintf(f,"%s %s %s %s %s %s\n",r.CIN_r,r.text_reclamation,r.ref_r,r.jour,r.mois,r.annee);
fclose(f);
}
 
/*supp*/
void supprimer(char CIN_r[])
{
char  ch3[20],ch4[20],ch5[20],ch6[20];
char ch1[20],ch2[30];

FILE*f=NULL,*fcopy=NULL;
f=fopen("reclamation.txt","r+");
 fcopy=fopen("reclamationnv.txt","a+");
if(f==NULL)
  {printf("impo");}
else
{
   while(fscanf(f,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
   {
     if (strcmp(CIN_r,ch1)!=0)
        fprintf(fcopy,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6);
   }
}
fclose(fcopy);
fclose(f);
remove("reclamation.txt");
rename("reclamationnv.txt","reclamation.txt");

}

/*modifier*/
void modifier(reclamation r)
{ 
char  ch3[20],ch4[20],ch5[20],ch6[20];
char ch1[20],ch2[30];
FILE*f,*fcopy;
f=fopen("reclamation.txt","r+");
fcopy=fopen("reclamationnv.txt","a");
if(f==NULL)
{printf("impo");}
else
{
while(fscanf(f,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
{
if (strcmp(r.CIN_r,ch1)!=0)
fprintf(fcopy,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6);
else 
fprintf(fcopy,"%s %s %s %s %s %s\n",r.CIN_r,r.text_reclamation,r.ref_r,r.jour,r.mois,r.annee);
}
}
fclose(fcopy);
fclose(f);
remove("reclamation.txt");
rename("reclamationnv.txt","reclamation.txt");
}



/*affichage*/

void affichage()
{
char  ch3[20],ch4[20],ch5[20],ch6[20];
char ch1[20],ch2[30];
FILE*f;
f=fopen("reclamation.txt","r");
if (f==NULL)
  {printf("vide");} 
else 
{
    while(fscanf(f,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
   {
       printf("%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6);
   }
}
fclose(f);
}




/*afficher_reclamation*/

void afficher_reclamation(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char CIN_r[20];
	char ref_r[10];
	char text_reclamation[30];
	char jour[10];
        char mois[10] ;
        char annee[10];
	store=NULL;

	FILE *f;
	
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("CIN_r", renderer, "text",cin,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("ref_r", renderer, "text",REF_r,NULL);                                                           
			
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("text_reclamation", renderer, "text",RECLA,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",DAY,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",MONTH,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",YEAR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}
	
	store=gtk_list_store_new (COLUMNS_r, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("reclamation.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("reclamation.txt", "a+");
		while(fscanf(f,"%s %s %s %s %s %s\n" ,CIN_r,text_reclamation,ref_r,jour,mois,annee)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, cin, CIN_r, REF_r,ref_r, RECLA, text_reclamation, DAY, jour, MONTH , mois, YEAR, annee, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
}

/*le service le plus reclame*/
int service_reclamation()
{
int nb,nbrestaurant=0,nbhebergement=0;
char  ch3[20],ch4[20],ch5[20],ch6[20];
char ch1[20],ch2[30];
FILE*f;
f=fopen("reclamation.txt","r");
while(fscanf(f,"%s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
{

if(ch3=="1") 
{nbhebergement++;}
else
{nbrestaurant++;}
if (nbrestaurant<nbhebergement)
{nb=1;}
else 
{nb=2;}   
}
fclose(f);
return nb;
}



/*recherche*/
void  recherche_CIN( char CIN_recher[50],GtkWidget *liste)
{
FILE *f;

char CIN_r[20];
	char ref_r[10];
	char text_reclamation[30];
	char jour[10];
        char mois[10] ;
        char annee[10];

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;

store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("CIN_r", renderer, "text",cin,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("ref_r", renderer, "text",REF_r,NULL);                                                           
			
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("text_reclamation", renderer, "text",RECLA,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",DAY,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",MONTH,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",YEAR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}
	
	store=gtk_list_store_new (COLUMNS_r, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("reclamation.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("reclamation.txt", "a+");
		while(fscanf(f,"%s %s %s %s %s %s\n" ,CIN_r,text_reclamation,ref_r,jour,mois,annee)!=EOF)
		{
if (strstr(CIN_r,CIN_recher)!=NULL || strstr(ref_r,CIN_recher)!=NULL || strstr(text_reclamation,CIN_recher)!=NULL || strstr(jour,CIN_recher)!=NULL ){


gtk_list_store_append (store, &iter);
gtk_list_store_set (store, &iter, cin, CIN_r, REF_r,ref_r, RECLA, text_reclamation, DAY, jour, MONTH , mois, YEAR, annee, -1);
		
		}}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}

}

////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////rihem/////////////////////////////////////////////////////////












