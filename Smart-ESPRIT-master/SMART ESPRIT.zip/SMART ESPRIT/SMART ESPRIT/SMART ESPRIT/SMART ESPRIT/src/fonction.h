#include<gtk/gtk.h>
#include<stdio.h>
#include<string.h>

typedef struct   
{
int jour;
int mois;
int annee;
}date;

typedef struct  
{
char prenom[20];
char nom[20];
char nomutilisateur[20];
char motdepasse[20];
char sexe[20];
char role[20];
date datnaissance;
}personne;

void afficher_personne(GtkWidget *liste);
int verif(char log[],char pw[]);
void rech_personne ( char nomutilisateur_rech[20], GtkWidget *liste);
///////////////////////////////////////////OMAR///////////////////////////////////////////////////::
//les structures// omar

typedef struct 
{
int type;
char jour[20];
char heure[20];
char nom[20];
char ref[20];
char val[20];
}capteur;

//les fonctions// omar

void ajouter_o(capteur c);
int modifier_o(capteur m);
int supprimer_o(capteur m);
void aff_cap_o(GtkWidget *liste);
///////////////////////////////////////////OMAR///////////////////////////////////////////////////::

//////////////////////////////////WASSIM///////////////////////////////////////////////////:
typedef struct {

    int j;
    int m;
    int a;

}date_w;

typedef struct {

        int id;
        char prenom[20];
        char nom[20];
        date_w d;
	char bloc[2];
        int chambre;
        int tel;
        int niveau;

}etudiant_w;

void ajouter_hebergement(etudiant_w e, char *fname);
void supprimer_hebergement(etudiant_w e, char *fname);
void afficher_hebergement(GtkWidget *liste, char *fname);
void modifier_hebergement(etudiant_w e, char *fname);
etudiant_w chercher_hebergement(int id, char *fname);
char* nombre_etudiant(char *fname);


//#endif

//////////////////////////////////WASSIM///////////////////////////////////////////////////

///////////////////////////////////HAMZA//////////////////////////////////////////////////
typedef struct
{
int jour;
int mois;
int annee;
}Date;
typedef struct
{
char id[10];
Date date;
char aliment[10];
char type[10];
}Menu;

typedef struct
{
char jour[10];
char temps[10];
char valeur[10];
}Dechet;

void Ajouter(Menu menu);
void Supprimer(char id[10],Menu menu);
void Afficher(GtkWidget *liste,char ch[50]);
void Chercher(char id[10],Menu menu);
void Modifier(char id[10],Menu menu);

//////////////////////////////////////HAMZA/////////////////////////////////////////////////////


////////////////////////////////////////////siwar////////////////////////////////////////////////////
typedef struct stock
{
char exemple[20];
char aliment[20];
char id [20];
int quantite;
char prix [20];
char importe [20];
}stock;


void ajout_siwar(stock p);

//void afficher1 (GtkWidget *liste);//
void rech_produit ( char produit_rech[1000], GtkWidget *liste);

void afficher_siwar (GtkWidget *liste);
void supprimer_siwar(char id[50]);
void modifier_siwar(stock c) ;

int exist_reference(char *id);
int exist_aliment(char *aliment);
void modifier_siwar1(stock c);
int exist1_id(char *id );
void afficher_enfaiedh(GtkWidget *liste);
///////////////////////////////////////////siwar//////////////////////////////////////////////////////


///////////////////////////////////////rihem/////////////////////////////////////////////////////////
typedef struct 
{ 
  char CIN_r[20];
  char text_reclamation [100];
  char ref_r[20];
  char jour[20]; 
  char mois[20];
  char annee[20];
}reclamation;

char CIN_r[20], ch [100];

void ajout(reclamation r);
void affichage();
void supprimer(char CIN_r[]);
void modifier(reclamation r );
int service_reclamation();
void afficher_reclamation(GtkWidget *liste);
//int recherche_reclamation(char ch []);
void  recherche_CIN( char CIN_recher[50],GtkWidget *liste);
///////////////////////////////////////rihem/////////////////////////////////////////////////////////





