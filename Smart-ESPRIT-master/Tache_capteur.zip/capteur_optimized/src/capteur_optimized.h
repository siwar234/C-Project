#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <gtk/gtk.h>

//les structures// omar

typedef struct 
{
int type;
char jour[20];
char heure[20];
char nom[20];
char ref[20];
char val[20];
}capteur;

//les fonctions// omar

void ajouter_o(capteur c);
int modifier_o(capteur m);
int supprimer_o(capteur m);
void aff_cap_o(GtkWidget *liste);









