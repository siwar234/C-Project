#include <gtk/gtk.h>


void
on_treeview_o_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_true_actualiser_o_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_o_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_menu_rechercher_o_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_ajouter_o_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_ok_o_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_supprimer_o_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_info_consulter_o_clicked     (GtkButton       *button,
                                        gpointer         user_data);
