#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur_optimized.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

void
on_button_menu_rechercher_o_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
    FILE* f;
    FILE* f1;
    FILE* f2;
    FILE* f3;
    FILE* f4;
    capteur c;
    int trouve1=0;
    int trouve2=0;
    int trouve3=0;
    int trouve4=0;
    int trouve5=0;
    int x;
    capteur m;
    char TYPE[50];
    char JOUR[50];
    char HEURE[50];
    char NOM[50];
    char REF[50];
    char VAL[50];
    char MESSAGE[300];

    GtkWidget *spinbutton_recherche;
    GtkWidget *entry_menu_recherche;
    GtkWidget *label_recherche;

    spinbutton_recherche = lookup_widget(button, "spinbutton_recherche") ;
    entry_menu_recherche = lookup_widget(button, "entry_menu_recherche") ;
    label_recherche = lookup_widget(button, "label_recherche") ;

    strcpy((m.ref),gtk_entry_get_text(GTK_ENTRY(entry_menu_recherche)));

    if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche))==1)
        x=1;
    else if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche))==2)
        x=2;
    else if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche))==3)
        x=3;
    else if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche))==4)
        x=4;
    else if(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_recherche))==5)
        x=5;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(x==1)
    {
        trouve1=0;
        f=fopen("temp.txt","r");
        if(f!=NULL)
        {
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Température");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve1=1;
                }
                if(trouve1==1)
                {
                    sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s °c.",TYPE,JOUR,HEURE,NOM,REF,VAL);
                }


                else
                {
                    strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀)");
                    printf("%s",MESSAGE);
                }


            }

            fclose(f);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if(x==2)
    {
        trouve2=0;
        f1=fopen("debit.txt","r");
        if(f1!=NULL)
        {
            while (fscanf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Débit");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve2=1;
                }
                if(trouve2==1)
                {
                    sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s L/s.",TYPE,JOUR,HEURE,NOM,REF,VAL);
                }


                else
                {
                    strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀)");
                    printf("%s",MESSAGE);
                }


            }

            fclose(f1);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if(x==3)
    {
        trouve3=0;
        f2=fopen("dechet.txt","r");
        if(f2!=NULL)
        {
            while (fscanf(f2,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Déchet");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve3=1;
                }
                if(trouve3==1)
                {
                    sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s g.",TYPE,JOUR,HEURE,NOM,REF,VAL);
                }


                else
                {
                    strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀)");
                    printf("%s",MESSAGE);
                }


            }

            fclose(f2);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if(x==4)
    {
        trouve4=0;
        f3=fopen("mouve.txt","r");
        if(f3!=NULL)
        {
            while (fscanf(f3,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Mouvement");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve4=1;
                }
                if(trouve4==1)
                {
                    sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s .",TYPE,JOUR,HEURE,NOM,REF,VAL);
                }


                else
                {
                    strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀)");
                    printf("%s",MESSAGE);
                }


            }

            fclose(f3);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if(x==5)
    {

        trouve5=0;
        f4=fopen("fumee.txt","r");
        if(f4!=NULL)
        {

            while (fscanf(f4,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {
                if(strcmp((c.ref),(m.ref))==0)
                {
                    strcpy(TYPE,"Fumée");
                    strcpy(JOUR,(c.jour));
                    strcpy(HEURE,(c.heure));
                    strcpy(NOM,(c.nom));
                    strcpy(REF,(c.ref));
                    strcpy(VAL,(c.val));

                    strcat(MESSAGE,TYPE);
                    strcat(MESSAGE,JOUR);
                    strcat(MESSAGE,HEURE);
                    strcat(MESSAGE,NOM);
                    strcat(MESSAGE,REF);
                    strcat(MESSAGE,VAL);
                    trouve5=1;
                }
            }
            if(trouve5==1)
            {
                sprintf(MESSAGE," Votre capteur est de type : %s.\n\n Mis le : %s à %s h.\n\n Sous le nom : %s.\n\n De référence : %s.\n\n De valeur : %s .",TYPE,JOUR,HEURE,NOM,REF,VAL);
            }


            else
            {
                strcpy(MESSAGE,"Référence introuvable (⌣̩̩́_⌣̩̩̀) ");
                printf("%s",MESSAGE);
            }




            fclose(f4);
        }
        else printf("\n ERROR!!");

        gtk_label_set_text(GTK_LABEL(label_recherche),MESSAGE);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }

}

void
on_button_ajouter_ajouter_o_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	capteur c;

    GtkWidget *entry_ajouter_jour;
    GtkWidget *entry_ajouter_heure;
    GtkWidget *entry_ajouter_nom;
    GtkWidget *entry_ajouter_ref;
    GtkWidget *entry_ajouter_valeur;
    GtkWidget *label_ajouter;

    entry_ajouter_jour = lookup_widget(button, "entry_ajouter_jour") ;
    entry_ajouter_heure = lookup_widget(button, "entry_ajouter_heure");
    entry_ajouter_nom = lookup_widget(button, "entry_ajouter_nom") ;
    entry_ajouter_ref = lookup_widget(button, "entry_ajouter_ref");
    entry_ajouter_valeur = lookup_widget(button, "entry_ajouter_valeur");
    label_ajouter = lookup_widget(button, "label_ajouter");


    strcpy((c.jour),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_jour)));
    strcpy((c.heure),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_heure)));
    strcpy((c.nom),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_nom)));
    strcpy((c.ref),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_ref)));
    strcpy((c.val),gtk_entry_get_text(GTK_ENTRY(entry_ajouter_valeur)));

    char MESSAGE[300];
    char NN[150];
    char UI[150];

    strcpy(NN,"Veuillez remplir tout les champs");
    strcpy(UI,"Ajout effectuée avec succès! ヽ(•‿•)ノ");
    strcat(MESSAGE,NN);
    strcat(MESSAGE,UI);
    
    GtkWidget *combobox_ajouter_type;
    combobox_ajouter_type = lookup_widget(button, "combobox_ajouter_type") ;

    if(strcmp("Température",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type)))==0)
        (c.type)=1;
    else if(strcmp("Débit",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type)))==0)
        (c.type)=2;
    else if(strcmp("Déchet",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type)))==0)
        (c.type)=3;
    else if(strcmp("Mouvement",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type)))==0)
        (c.type)=4;
    else if(strcmp("Fumée",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ajouter_type)))==0)
        (c.type)=5;
 
    if((strcmp(c.jour,"")==0) || (strcmp(c.heure,"")==0) || (strcmp(c.nom,"")==0) || (strcmp(c.ref,"")==0) || (strcmp(c.val,"")==0))
    {
        sprintf(MESSAGE,"%s",NN);
    }
    else
    {
        ajouter_o(c);
        sprintf(MESSAGE,"%s",UI);
    }
    gtk_label_set_text(GTK_LABEL(label_ajouter),MESSAGE);

}

void
on_button_modifier_ok_o_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
    capteur m;

    GtkWidget *entry_modifier_type;
    GtkWidget *entry_modifier_nom_new;
    GtkWidget *entry_modifier_jour;
    GtkWidget *entry_modifier_heure;
    GtkWidget *entry_modifier_ref;
    GtkWidget *entry_modifier_val;
    GtkWidget *label_modifier;

    entry_modifier_type = lookup_widget(button, "entry_modifier_type") ;
    entry_modifier_nom_new = lookup_widget(button, "entry_modifier_nom_new") ;
    entry_modifier_jour = lookup_widget(button, "entry_modifier_jour") ;
    entry_modifier_heure = lookup_widget(button, "entry_modifier_heure") ;
    entry_modifier_ref = lookup_widget(button, "entry_modifier_ref") ;
    entry_modifier_val = lookup_widget(button, "entry_modifier_val") ;
    label_modifier = lookup_widget(button, "label_modifier") ;

    (m.type)=gtk_entry_get_text(GTK_ENTRY((entry_modifier_type)));
    strcpy((m.nom),gtk_entry_get_text(GTK_ENTRY(entry_modifier_nom_new)));
    strcpy((m.jour),gtk_entry_get_text(GTK_ENTRY(entry_modifier_jour)));
    strcpy((m.heure),gtk_entry_get_text(GTK_ENTRY(entry_modifier_heure)));
    strcpy((m.ref),gtk_entry_get_text(GTK_ENTRY(entry_modifier_ref)));
    strcpy((m.val),gtk_entry_get_text(GTK_ENTRY(entry_modifier_val)));
//////////////////////////////////////////////////////////////////////////////////////
    char MESSAGE_M[300];
    char ui[150];
    char NN[150];

    strcpy(ui,"Modification effectuée avec succès! ヽ(•‿•)ノ");
    strcpy(NN,"Vérifier vos données");
    strcat(MESSAGE_M,ui);	
    strcat(MESSAGE_M,NN);

 int modi = modifier_o(m);

    if( modi==1 )
        sprintf(MESSAGE_M,"%s",ui);
    else
	        sprintf(MESSAGE_M,"%s",NN);

	    gtk_label_set_text(GTK_LABEL(label_modifier),MESSAGE_M);
//////////////////////////////////////////////////////////////////////////////////////
}



void
on_button_actualiser_o_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *treeview_o,*espace_tech;

    espace_tech=lookup_widget(button,"espace_tech");

    treeview_o = lookup_widget (button,"treeview_o");

    aff_cap_o(treeview_o);
}


void
on_treeview_o_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
    GtkTreeIter iter;
    gint* type;
    gchar* jour;
    gchar* heure;
    gchar* nom;
    gchar* ref;
    gchar* val;

    capteur c;

    GtkTreeModel *model = gtk_tree_view_get_model(treeview);

    if (gtk_tree_model_get_iter(model, &iter,path))
    {
        gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0,&type,1,&jour,2,&heure,3,&nom,4,&ref,5,&val, -1);
        c.type=type;
        strcpy((c.jour),jour);
        strcpy((c.heure),heure);
        strcpy((c.nom),nom);
        strcpy((c.ref),ref);
        strcpy((c.val),val);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}

void
on_button_supprimer_supprimer_o_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
    capteur m;
    capteur c;
    FILE *f;

    GtkWidget *entry_supprimer_ref;
    GtkWidget *label_supprimer;

    char MESSAGE[300];
    char NN[150];
    char UI[150];
    char nn[150];

    strcpy(UI,"Suppression effectuée avec succès! ヽ(•‿•)ノ");
    strcpy(nn,"Vérifier vos données");
    strcat(MESSAGE,UI);	
    strcat(MESSAGE,nn);

    entry_supprimer_ref = lookup_widget(button, "entry_supprimer_ref") ;
    label_supprimer = lookup_widget(button, "label_supprimer") ;

    strcpy((m.ref),gtk_entry_get_text(GTK_ENTRY(entry_supprimer_ref)));

 int supp=   supprimer_o(m);

    if( supp==1 )
        sprintf(MESSAGE,"%s",UI);
    else
	        sprintf(MESSAGE,"%s",nn);

	    gtk_label_set_text(GTK_LABEL(label_supprimer),MESSAGE);
}

void
on_button_info_consulter_o_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *label_info_temp;
    label_info_temp = lookup_widget(button, "label_info_temp") ;
    GtkWidget *label_info_debit;
    label_info_debit = lookup_widget(button, "label_info_debit") ;
    GtkWidget *label_info_dechet;
    label_info_dechet = lookup_widget(button, "label_info_dechet") ;
    GtkWidget *label_info_mouve;
    label_info_mouve = lookup_widget(button, "label_info_mouve") ;
    GtkWidget *label_info_fumee;
    label_info_fumee = lookup_widget(button, "label_info_fumee") ;

    int seuil_debit_max=30, seuil_debit_min=0, val_dechet=100;
    int seuil_temp_max=30, seuil_temp_min=10;
    char MESSAGE_TEMP[400]="";
    char MESSAGE_DEBIT[400]="";
    char MESSAGE_DECHET[400]="";
    char MESSAGE_MOUVE[400]="";
    char MESSAGE_FUMEE[400]="";
    int VAL=NULL;
    capteur c;

    FILE* f;
    FILE* f1;
    FILE* f2;
    FILE* f3;
    FILE* f4;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
   f=fopen("temp.txt","r");
    if(f!=NULL)
    {
        char MESSAGE_TEMPO[50];
        char NOM_TEMP[20];

        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {
            VAL=atoi(c.val);
            strcpy(NOM_TEMP,(c.nom));
            strcat(MESSAGE_TEMPO,NOM_TEMP);

            if((seuil_temp_max<VAL)  || (seuil_temp_min>VAL))
            {
                sprintf(MESSAGE_TEMPO,"Le capteur %s est déféctueux\n",NOM_TEMP);
                strcat(MESSAGE_TEMP,MESSAGE_TEMPO);
            }

            else
            {
                sprintf(MESSAGE_TEMPO,"Le capteur %s est stable\n",NOM_TEMP);
                strcat(MESSAGE_TEMP,MESSAGE_TEMPO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_temp),MESSAGE_TEMP);

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("debit.txt","r");
    if(f!=NULL)
    {
        VAL=0;
        char MESSAGE_DEBITO[50];
        char NOM_DEBIT[20];
        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {

            VAL=atoi(c.val);
            strcpy(NOM_DEBIT,(c.nom));
            strcat(MESSAGE_DEBITO,NOM_DEBIT);

            if((seuil_debit_max<VAL)  || (seuil_debit_min>VAL))
            {
                sprintf(MESSAGE_DEBITO,"Le capteur %s est déféctueux\n",NOM_DEBIT);
                strcat(MESSAGE_DEBIT,MESSAGE_DEBITO);
            }

            else
            {
                sprintf(MESSAGE_DEBITO,"Le capteur %s est stable\n",NOM_DEBIT);
                strcat(MESSAGE_DEBIT,MESSAGE_DEBITO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_debit),MESSAGE_DEBIT);

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("dechet.txt","r");
    if(f!=NULL)
    {
        VAL=0;
        char MESSAGE_DECHETO[100];
        char NOM_DECHET[40];
        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {

            VAL=atoi(c.val);
            strcpy(NOM_DECHET,(c.nom));
            strcat(MESSAGE_DECHETO,NOM_DECHET);

            if(val_dechet<VAL)
            {
                sprintf(MESSAGE_DECHETO,"%s a tros de déchet\n",NOM_DECHET);
                strcat(MESSAGE_DECHET,MESSAGE_DECHETO);
            }

            else
            {
                sprintf(MESSAGE_DECHETO,"Le meilleur plat appartient au %s\n",NOM_DECHET);
                strcat(MESSAGE_DECHET,MESSAGE_DECHETO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_dechet),MESSAGE_DECHET);

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("mouve.txt","r");
    if(f!=NULL)
    {
        VAL=0;
        char MESSAGE_MOUVEO[100];
        char NOM_MOUVE[40];
        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {

            VAL=atoi(c.val);
            strcpy(NOM_MOUVE,(c.nom));
            strcat(MESSAGE_MOUVEO,NOM_MOUVE);

            if(VAL==0)
            {
                sprintf(MESSAGE_MOUVEO,"Pas de mouvement au niveau du capteur %s\n",NOM_MOUVE);
                strcat(MESSAGE_MOUVE,MESSAGE_MOUVEO);
            }

            else
            {
                sprintf(MESSAGE_MOUVEO,"Le capteur %s détecte un mouvement\n",NOM_MOUVE);
                strcat(MESSAGE_MOUVE,MESSAGE_MOUVEO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_mouve),MESSAGE_MOUVE);

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("fumee.txt","r");
    if(f!=NULL)
    {
        VAL=0;
        char MESSAGE_FUMEEO[100];
        char NOM_FUMEE[40];

        while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
        {

            VAL=atoi(c.val);
            strcpy(NOM_FUMEE,(c.nom));
            strcat(MESSAGE_FUMEEO,NOM_FUMEE);

            if(VAL==0)
            {
                sprintf(MESSAGE_FUMEEO,"Pas de fumée au niveau du capteur %s\n",NOM_FUMEE);
                strcat(MESSAGE_FUMEE,MESSAGE_FUMEEO);
            }

            else
            {
                sprintf(MESSAGE_FUMEEO,"Le capteur %s détecte un gaz\n",NOM_FUMEE);
                strcat(MESSAGE_FUMEE,MESSAGE_FUMEEO);
            }

        }
        fclose(f);
    }
    else printf("\n ERROR!!");

    gtk_label_set_text(GTK_LABEL(label_info_fumee),MESSAGE_FUMEE);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

void
on_button_true_actualiser_o_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *espace_tech;
    espace_tech = lookup_widget(button, "espace_tech") ;

    gtk_widget_destroy(espace_tech);
    espace_tech = create_espace_tech ();
    gtk_widget_show(espace_tech);
}


