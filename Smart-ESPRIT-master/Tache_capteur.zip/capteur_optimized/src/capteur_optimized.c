///////////////////////////////////////////////////////////////OMAR////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "capteur_optimized.h"
#include <gtk/gtk.h>

enum
{
    TYPE,
    JOUR,
    HEURE,
    NOM,
    REF,
    VAL,
    COLUMNS
};

void aff_cap_o (GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

    int  type;
    char jour[20];
    char heure[20];
    char nom[20];
    char ref[20];
    char val[20];
    store = NULL;

    FILE *f;

    store=gtk_tree_view_get_model(liste);

    if (store==NULL)
    {

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("heure",renderer,"text",HEURE,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("ref",renderer,"text",REF,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("val",renderer,"text",VAL,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        store=gtk_list_store_new(COLUMNS,G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

        f = fopen("temp.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("temp.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
        }

        f = fopen("debit.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("debit.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
        }
        f = fopen("dechet.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("dechet.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
        }
        f = fopen("mouve.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("mouve.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
        }
        f = fopen("fumee.txt","r");

        if (f==NULL)
        {
            return;
        }
        else
        {
            f = fopen("fumee.txt","a+");
            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&type,jour,heure,nom,ref,val)!=EOF)
            {
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store,&iter,TYPE,type,JOUR,jour,HEURE,heure,NOM,nom,REF,ref,VAL,val, -1);

            }
            fclose(f);

            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);
        }
    }

}

/////////les fonctions/////////// 

void ajouter_o(capteur c)
{

    FILE* f;


    if ((c.type)==1)
    {
        f=fopen("temp.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val));
            fclose(f);
        }
        else printf("\n ERROR!!");
    }


    if ((c.type)==2)
    {
        f=fopen("debit.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );
            fclose(f);
        }
        else printf("\n ERROR!!");
    }

    if ((c.type)==3)
    {
        f=fopen("dechet.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );
            fclose(f);
        }
        else printf("\n ERROR!!");
    }

    if ((c.type)==4)
    {
        f=fopen("mouve.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );
            fclose(f);
        }
        else printf("\n ERROR!!");
    }

    if ((c.type)==5)
    {
        f=fopen("fumee.txt","a+");
        if(f!=NULL)
        {
            fprintf(f,"%d\t %s\t %s\t %s\t %s\t %s\n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );
            fclose(f);
        }
        else printf("\n ERROR!!");
    }
}
//////////////////////////////////////////////////////////////////////////////

int modifier_o(capteur m)
{
    FILE* f;
    FILE* f1;
    capteur c;
    int modi=0;
///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("temp.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {

            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==1) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );




            }
            remove("temp.txt");
            rename("replace.txt","temp.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");
///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("debit.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==2) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("debit.txt");
            rename("replace.txt","debit.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    f=fopen("dechet.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==3) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("dechet.txt");
            rename("replace.txt","dechet.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");
///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("mouve.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==4) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("mouve.txt");
            rename("replace.txt","mouve.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");
///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("fumee.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((c.type==5) && (strcmp(m.ref,c.ref)==0))
                {


                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(m.jour),(m.heure),(m.nom),(m.ref),(m.val) );
			modi=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("fumee.txt");
            rename("replace.txt","fumee.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////
return modi;
}

int supprimer_o(capteur m)
{
    FILE* f;
    FILE* f1;
    capteur c;
    int supp=0;

///////////////////////////////////////////////////////////////////////////////////////////////////////

   f=fopen("temp.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;


                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );

            }
            remove("temp.txt");
            rename("replace.txt","temp.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");


        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("debit.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;

                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );


            }
            remove("debit.txt");
            rename("replace.txt","debit.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("dechet.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {



            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;

                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );



            }
            remove("dechet.txt");
            rename("replace.txt","dechet.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("mouve.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;

                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );


            }
            remove("mouve.txt");
            rename("replace.txt","mouve.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////

    f=fopen("fumee.txt","r");
    if(f!=NULL)
    {

        f1=fopen("replace.txt","a+");
        if(f1!=NULL)
        {


            while (fscanf(f,"%d\t %s\t %s\t %s\t %s\t %s \n",&(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val))!=EOF)
            {


                if ((strcmp(m.ref,c.ref)==0))
                {
supp=1;

                }
                else

                    fprintf(f1,"%d\t %s\t %s\t %s\t %s\t %s \n",(c.type),(c.jour),(c.heure),(c.nom),(c.ref),(c.val) );


            }
            remove("fumee.txt");
            rename("replace.txt","fumee.txt");
            fclose(f1);
        }
        else printf("\n ERRORFFF!!");



        fclose(f);
    }
    else printf("\n ERROR!!");

///////////////////////////////////////////////////////////////////////////////////////////////////////
return supp;
}















