#include <gtk/gtk.h>


void
on_button_affichage_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_add_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_okk_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_returnadd_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_sup_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_returnsup_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modf_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button_returnmodif_clicked          (GtkButton       *button,
                                        gpointer         user_data);




void
on_button_aff_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_servicereclame_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_service_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_recherche_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_resultat_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton  *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
