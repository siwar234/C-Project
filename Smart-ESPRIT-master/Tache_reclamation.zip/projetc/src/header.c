#include "header.h"
#include <stdio.h>
#include<string.h>
#include <string.h>
#include <stdlib.h>// ETYPE, type, EID, id, EMARQUE, marque, EVALEUR, valeur, EMIN , min, EMAX
			enum{
			cin,
			REF,
			RECLA,
			DAY,
			MONTH,
			YEAR,
			COLUMNS
			};
					/* 
 					 char CIN[20];
 				 	char text_reclamation[30];
 					 char ref;
 					 char jour; 
 			 		char mois;
  					char annee;*/
/*ajou*/
void ajout(reclamation r)
{ 
FILE*f;
f=fopen("reclamation.txt","a");
fprintf(f,"%s %s %s %s %s %s\n",r.CIN,r.text_reclamation,r.ref,r.jour,r.mois,r.annee);
fclose(f);
}
 
/*supp*/
void supprimer(char CIN[])
{
char  ch3[20],ch4[20],ch5[20],ch6[20];
char ch1[20],ch2[30];

FILE*f=NULL,*fcopy=NULL;
f=fopen("reclamation.txt","r+");
 fcopy=fopen("reclamationnv.txt","a+");
if(f==NULL)
  {printf("impo");}
else
{
   while(fscanf(f,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
   {
     if (strcmp(CIN,ch1)!=0)
        fprintf(fcopy,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6);
   }
}
fclose(fcopy);
fclose(f);
remove("reclamation.txt");
rename("reclamationnv.txt","reclamation.txt");

}

/*modifier*/
void modifier(reclamation r)
{ 
char  ch3[20],ch4[20],ch5[20],ch6[20];
char ch1[20],ch2[30];
FILE*f,*fcopy;
f=fopen("reclamation.txt","r+");
fcopy=fopen("reclamationnv.txt","a");
if(f==NULL)
{printf("impo");}
else
{
while(fscanf(f,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
{
if (strcmp(r.CIN,ch1)!=0)
fprintf(fcopy,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6);
else 
fprintf(fcopy,"%s %s %s %s %s %s\n",r.CIN,r.text_reclamation,r.ref,r.jour,r.mois,r.annee);
}
}
fclose(fcopy);
fclose(f);
remove("reclamation.txt");
rename("reclamationnv.txt","reclamation.txt");
}



/*affichage*/

void affichage()
{
char  ch3[20],ch4[20],ch5[20],ch6[20];
char ch1[20],ch2[30];
FILE*f;
f=fopen("reclamation.txt","r");
if (f==NULL)
  {printf("vide");} 
else 
{
    while(fscanf(f,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
   {
       printf("%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6);
   }
}
fclose(f);
}




/*afficher_reclamation*/

void afficher_reclamation(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char CIN[20];
	char ref[10];
	char text_reclamation[30];
	char jour[10];
        char mois[10] ;
        char annee[10];
	store=NULL;

	FILE *f;
	
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",cin,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("ref", renderer, "text",REF,NULL);                                                           
			
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("text_reclamation", renderer, "text",RECLA,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",DAY,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",MONTH,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",YEAR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}
	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("reclamation.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("reclamation.txt", "a+");
		while(fscanf(f,"%s %s %s %s %s %s\n" ,CIN,text_reclamation,ref,jour,mois,annee)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, cin, CIN, REF,ref, RECLA, text_reclamation, DAY, jour, MONTH , mois, YEAR, annee, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
}

/*le service le plus reclame*/
int service_reclamation()
{
int nb,nbrestaurant=0,nbhebergement=0;
char ch1[20],ch2[30],ch3[20],ch4[20],ch5[20],ch6[20];
FILE*f;
f=fopen("reclamation.txt","r");
while(fscanf(f,"%s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
{

if(ch3=="1") 
{nbhebergement++;}
else
{nbrestaurant++;}
if (nbrestaurant<nbhebergement)
{nb=1;}
else 
{nb=2;}   
}
fclose(f);
return nb;
}



/*recherche*/
int recherche(char CIN[])
{
int trouve=0;
char ch1[20],ch2[30],ch3[20],ch4[20],ch5[20],ch6[20];
FILE*f;
f=fopen("reclamation.txt","r");
while(fscanf(f,"%s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
{
if( strcmp(ch1,CIN)==0)
{trouve=1;}
}
fclose(f);

return trouve;
}


int recherche_reclamation(char ch[])
{
int nb=0;
char ch1[20],ch2[30],ch3[20],ch4[20],ch5[20],ch6[20];
FILE*f;
f=fopen("reclamation.txt","r");
while(fscanf(f,"%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
{
if (strcmp(ch,ch2)==0)
 nb=1;
return nb ;
}
}







