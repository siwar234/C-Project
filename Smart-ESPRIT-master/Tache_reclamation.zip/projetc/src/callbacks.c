#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
 #include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "header.h"

int x;
int y;
void
on_button_affichage_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *aff,*recla;
aff=create_affichage();
gtk_widget_show(aff);
recla=lookup_widget (objet_graphique,"create_reclamation");
gtk_widget_destroy(recla);

}


void
on_button_add_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajout;
ajout=create_add();
gtk_widget_show(ajout);
}



void
on_button_okk_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
reclamation r ;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*aff;
input1=lookup_widget(objet_graphique,"entry_cin");
if(y==1)
strcpy(r.ref,"1");
else
strcpy(r.ref,"2");

input3=lookup_widget(objet_graphique,"entry_autre");

input4= lookup_widget (objet_graphique , "combobox1");
input5= lookup_widget (objet_graphique , "combobox2");
input6= lookup_widget (objet_graphique , "combobox3");

strcpy(r.CIN,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(r.text_reclamation,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy (r.jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy (r.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
strcpy (r.annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
if (x==1)
{
ajout(r);
aff=create_affichage();
gtk_widget_show(aff);
}
}


void
on_button_returnadd_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *reclama;
reclama=create_reclamation();
gtk_widget_show(reclama);
}


void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *sup;
sup=create_supprimer() ;
gtk_widget_show (sup);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	
	gchar* CIN; 
	gchar* ref; 
	gchar* text_reclamation;  
        gchar* jour;
        gchar* mois;
	gchar* annee;
	reclamation r;
	
	FILE *f=NULL;


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{gtk_tree_model_get (GTK_LIST_STORE(model),0,&CIN,1,&ref,2,&text_reclamation,3,&jour,4,&mois,5,&annee,-1);

	strcpy(r.CIN,CIN);
	strcpy(r.ref,ref);
        strcpy(r.text_reclamation,text_reclamation);
	strcpy(r.jour,jour);
        strcpy(r.mois,mois);
        strcpy(r.annee,annee);}

	
        afficher_reclamation(treeview);

}


void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier;
modifier=create_modifier() ;
gtk_widget_show (modifier);
}


void
on_button_sup_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*aff;
char ch[20];
input1=lookup_widget(objet_graphique,"entry_cin");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input1)));
supprimer(ch);
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_returnsup_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aff;
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_modf_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
reclamation r ;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*affichage,*aff;
input1=lookup_widget(objet_graphique,"entry_cin");
input2=lookup_widget(objet_graphique,"entry_ref");
input3=lookup_widget(objet_graphique,"entry_text");
input4=lookup_widget(objet_graphique,"entry_jour");
input5=lookup_widget(objet_graphique,"entry_mois");
input6=lookup_widget(objet_graphique,"entry_annee");
strcpy(r.CIN,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.ref,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.text_reclamation,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(r.jour,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(r.mois,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(r.annee,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier(r);
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_returnmodif_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aff;
aff=create_affichage();
gtk_widget_show(aff);
}



void
on_button_aff_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
treeview1=lookup_widget(objet_graphique,"treeview1");
afficher_reclamation(treeview1);
}


void
on_button_servicereclame_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *service;
service=create_service_();
gtk_widget_show(service);
}


void
on_button_service_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*nb ,*l;
char ch[40];
int k;
k=service_reclamation();
l=lookup_widget(objet,"label4");
if (k==1)
{sprintf(ch,"hebergement");}
if (k==2)
{sprintf(ch,"restauration");}
gtk_label_set_text(GTK_LABEL(l),ch);
}




void
on_button_recherche_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *recherche;
recherche=create_recherche();
gtk_widget_show(recherche);
}


void
on_button_resultat_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget*nb ,*l,*l1;
char ch[40],ch1[100];
int k;
l1=lookup_widget(objet_graphique,"entry_recherche");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(l1)));
l=lookup_widget(objet_graphique,"label6");
k=recherche_reclamation(ch1);
if (k==1)
{sprintf(ch,"existe");}
else
{sprintf(ch,"n'existe pas");}
gtk_label_set_text(GTK_LABEL(l),ch);
}
void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)

{
if(gtk_toggle_button_get_active(togglebutton))
x=1;
else 
x=0;

}





void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y=2;
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y=1;
}

