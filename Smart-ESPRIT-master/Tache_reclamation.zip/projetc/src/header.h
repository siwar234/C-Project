#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>




typedef struct 
{ 
  char CIN[20];
  char text_reclamation [100];
  char ref[20];
  char jour[20]; 
  char mois[20];
  char annee[20];
}reclamation;

char CIN[20], ch [100];

void ajout(reclamation r);
void affichage();
void supprimer(char CIN[]);
void modifier(reclamation r );
int service_reclamation();
int recherche(char CIN[]);
void afficher_reclamation(GtkWidget *liste);
int recherche_reclamation(char ch []);
