#include <gtk/gtk.h>


void
on_button_1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_3_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_4_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_hebergement_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
