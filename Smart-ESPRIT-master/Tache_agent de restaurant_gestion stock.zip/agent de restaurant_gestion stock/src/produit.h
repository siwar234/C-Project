#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <gtk/gtk.h>
typedef struct stock
{
char exemple[20];
char aliment[20];
char id [20];
int quantite;
char prix [20];
char importe [20];
}stock;


void ajout_siwar(stock p);

//void afficher1 (GtkWidget *liste);//
void rech_produit ( char produit_rech[1000], GtkWidget *liste);

void afficher_siwar (GtkWidget *liste);
void supprimer_siwar(char id[50]);
void modifier_siwar(stock c) ;

int exist_reference(char *id);
int exist_aliment(char *aliment);
void modifier_siwar1(stock c);
int exist1_id(char *id );
void afficher_enfaiedh(GtkWidget *liste);
