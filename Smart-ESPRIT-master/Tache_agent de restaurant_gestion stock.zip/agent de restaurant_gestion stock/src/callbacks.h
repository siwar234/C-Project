#include <gtk/gtk.h>


void
on_button1_stock_clicked               (GtkButton       *button,
                                        gpointer         user_data);



void
on_button5_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);





void
on_retour_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);


void
on_image14_accel_closures_changed      (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button4_rupture_clicked             (GtkButton       *button,
                                        gpointer         user_data);





void
on_button9_supprimer_clicked           (GtkWidget      *objet,
                                        gpointer         user_data);



void
on_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);






void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_dialog_ajouter_produit_activate_default
                                        (GtkWindow       *window,
                                        gpointer         user_data);



void
on_quitter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);



void
on_home_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_affiche_rupture_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_retourner_rupture_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actualiser_rupture_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_siwar_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);




void
on_treeview_rupture_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton2_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajout_si_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_si_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_radiobutton2_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modifier_si_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_actualiser_si_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button11_si_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button13_si_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_button12_si_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);
