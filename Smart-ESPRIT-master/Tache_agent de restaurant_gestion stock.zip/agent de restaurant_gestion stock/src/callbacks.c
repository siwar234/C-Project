#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif



#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"produit.h"

stock p;
int choix=0;
void
on_button1_stock_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *window_produit;
GtkWidget  *window_stock;
window_stock=lookup_widget(button, "window_stock");
window_produit=lookup_widget(button, "window_produit");
window_produit=create_window_produit();
gtk_widget_show(window_produit);
}


















void
on_button4_rupture_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget  *window_sorties;
GtkWidget  *window_stock;
window_stock=lookup_widget(button, "window_stock");
window_sorties=lookup_widget(button,"window_sorties");
window_sorties=create_window_sorties();
gtk_widget_show(window_sorties);


}







void
on_button9_supprimer_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*affiche,*w1;
        gchar* aliment;
        gchar* id;
        gchar* exemple;
        p=lookup_widget(objet,"treeview1_siwar");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&exemple,1,&aliment,2,&id,-1);

 
           supprimer_siwar(id);
	w1=lookup_widget(objet,"window_affiche");
	affiche = create_window_affiche();
	gtk_widget_show (affiche);
	gtk_widget_hide (w1);

	
GtkWidget *dialog_supprimer_produit,*window_affiche;

window_affiche=lookup_widget(objet, "window_affiche");
dialog_supprimer_produit=lookup_widget(objet, "dialog_supprimer_produit");
dialog_supprimer_produit=create_dialog_supprimer_produit();
gtk_widget_show(dialog_supprimer_produit);




}}


void
on_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *produit_input;
GtkWidget  *treeview1_siwar;
char produit_rech[10000];



treeview1_siwar=lookup_widget(objet,"treeview1_siwar");
produit_input=lookup_widget(objet,"entry5_si");
strcpy(produit_rech,gtk_entry_get_text(GTK_ENTRY(produit_input)));
rech_produit (produit_rech,treeview1_siwar);
}







void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *n1;
n1=lookup_widget(button,"dialog_ajouter_produit");
gtk_widget_destroy(n1);

//ajout(p);//
}






















void
on_quitter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_produit;
GtkWidget  *window_sorties;
GtkWidget  *window_affiche;
GtkWidget  *window_stock;
window_affiche=lookup_widget(objet, "window_affiche");
window_stock=lookup_widget(objet, "window_stock");

window_stock=create_window_stock();
gtk_widget_show(window_stock);

gtk_widget_hide (window_affiche);
gtk_widget_hide(window_sorties);
gtk_widget_hide(window_produit);
gtk_widget_hide(window_stock);
}


void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *n1;
n1=lookup_widget(button,"dialog_supprimer_produit");
gtk_widget_destroy(n1);
}



void
on_home_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_sorties;
GtkWidget  *window_stock;
window_sorties=lookup_widget(objet, "sorties");
window_stock=lookup_widget(objet, "window_stock");

window_stock=create_window_stock();
gtk_widget_show(window_stock);

gtk_widget_hide (window_sorties);
}


















void
on_affiche_rupture_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{


GtkWidget  *window_sorties;

GtkWidget  *window_valider;
window_sorties=lookup_widget(objet, "window_sorties");
window_valider=lookup_widget(objet, "window_valider");
window_valider=create_window_valider();
gtk_widget_show(window_valider);
}




void
on_treeview2_rupture_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

gchar* aliment;
gchar* id;

gint* quantite;



GtkTreeModel *model =gtk_tree_view_get_model(treeview);
 if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&aliment,1,&id,2,quantite,-1);

strcpy(p.aliment,aliment);
strcpy(p.id,id);
p.quantite=quantite;

}
}


void
on_retourner_rupture_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_valider;
GtkWidget  *window_sorties;
window_valider=create_window_valider();
window_sorties=create_window_sorties ();
gtk_widget_show(window_sorties);
}


void
on_actualiser_rupture_clicked          (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget *treeview_rupture;

  GtkWidget *window_valider;


window_valider=lookup_widget(objet, "window_valider");
treeview_rupture=lookup_widget(objet,"treeview_rupture");
afficher_enfaiedh(treeview_rupture);
}


void
on_treeview1_siwar_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* exemple;
gchar* aliment;
gchar* id;

gint* quantite;

gchar*  prix;
gchar* importe;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);
 if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&exemple,1,&aliment,2,&id,3,quantite,4,&prix,5,&importe,-1);
strcpy(p.exemple,exemple);
strcpy(p.aliment,aliment);
strcpy(p.id,id);
p.quantite=quantite;
strcpy(p.prix,prix);

strcpy(p.importe,importe);

}
}






void
on_treeview_rupture_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

gchar* aliment;
gchar* id;

gint* quantite;




GtkTreeModel *model =gtk_tree_view_get_model(treeview);
 if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&aliment,1,&id,2,&quantite,-1);

strcpy(p.aliment,aliment);
strcpy(p.id,id);
p.quantite=quantite;

}
}


void
on_checkbutton2_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	choix = 1 ;
}


void
on_checkbutton3_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	choix = 0 ;
}


void
on_ajout_si_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
int b=1;
GtkWidget  *window_produit; 
 GtkWidget 
*combobox,*existe,*input8,*input2,*input4,*spinbutton1,*oui,*non,*labelchampp;
window_produit=lookup_widget(objet, "window_produit");  
char nn[150];
char MESSAGE[50];



input8=lookup_widget(objet,"entry_produit"); 
combobox=lookup_widget(objet, "combobox_si"); 
input2=lookup_widget(objet,"entry2_si"); 
spinbutton1=lookup_widget(objet,"spinbutton_quantite");
input4=lookup_widget(objet, "entry4_si"); 
oui=lookup_widget(objet,"checkbutton2_si");
non=lookup_widget(objet,"checkbutton3_si");
labelchampp=lookup_widget(objet,"label_si");
existe=lookup_widget(objet,"label_existe");




/*strcpy(nn,"il faut remplir tous les champs");
strcat(MESSAGE,nn);}
if((strcmp(p.type,"")==0) || (strcmp(p.produit,"")==0) || (strcmp(p.reference,"")==0) ||  (strcmp(p.prix,"")==0) || (strcmp(p.importe,"")==0)){
sprintf(MESSAGE,"%s",nn);

gtk_label_set_text(GTK_LABEL(label_champ),MESSAGE);
 */






strcpy(p.exemple,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));

strcpy(p.aliment,gtk_entry_get_text(GTK_ENTRY(input8)));
p.quantite=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbutton1));
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input2)));

strcpy(p.prix,gtk_entry_get_text(GTK_ENTRY(input4)));

if(choix == 1)
	{


		strcpy(p.importe," oui");
         
	}

	if(choix == 0)
	{
		strcpy(p.importe,"non");

	}

if((strcmp(p.exemple,"")==0) || (strcmp(p.aliment,"")==0)  || (strcmp(p.id,"")==0) || (p.quantite=="") || (strcmp(p.prix,"")==0) || (strcmp(p.importe,"")==0)){
		  gtk_widget_show (labelchampp);

}
else if (exist_reference(p.id)==1)
        {

	       gtk_widget_show (existe);
        }

else {
		gtk_widget_hide (existe);
		  gtk_widget_hide(labelchampp);

ajout_siwar(p);


GtkWidget *dialog_ajouter_produit;

window_produit=lookup_widget(objet, "window_produit");
dialog_ajouter_produit=lookup_widget(objet, "dialog_ajouter_produit");
dialog_ajouter_produit=create_dialog_ajouter_produit();
gtk_widget_show(dialog_ajouter_produit);
}
}


void
on_afficher_si_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_produit;
GtkWidget  *window_affiche;
GtkWidget  *treeview1_siwar;

window_produit=lookup_widget(objet, "window_produit");
window_affiche=lookup_widget(objet, "window_affiche");
window_affiche=create_window_affiche();
gtk_widget_show(window_affiche);
treeview1_siwar=lookup_widget(objet,"treeview1_siwar");
}


void
on_radiobutton2_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	choix = 0 ;
}


void
on_radiobutton1_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	choix = 1 ;
}


void
on_modifier_si_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
stock c;
GtkWidget  *window_produit; 
 GtkWidget *input5,*produit, *reference,*input6,*spinbutton2,*importe,
 *oui,*non;

        input5=lookup_widget(objet,"combobox2_si");

	produit=lookup_widget(objet,"modifier_produit");

	reference=lookup_widget(objet,"modifier_reference"); 

spinbutton2=lookup_widget(objet,"spinbutton2_quantite");

        input6=lookup_widget(objet, "modifier_prix"); 
	oui=lookup_widget(objet,"radiobutton1_si");
        non=lookup_widget(objet,"radiobutton2_si");
	     strcpy(c.exemple,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
strcpy(c.aliment,gtk_entry_get_text(GTK_ENTRY(produit)));
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(reference)));
c.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));

strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(input6)));

if(choix == 1)
	{


		strcpy(c.importe," oui");
         
	}

	if(choix == 0)
	{
		strcpy(c.importe,"non");

	}
modifier_siwar(c);
}


void
on_actualiser_si_clicked               (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_affiche;
GtkWidget  *treeview1_siwar;


window_affiche=lookup_widget(objet, "window_affiche");

treeview1_siwar=lookup_widget(objet,"treeview1_siwar");
afficher_siwar(treeview1_siwar);
}


void
on_button11_si_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_sorties;
GtkWidget  *window_produit;
GtkWidget  *window_stock;
window_produit=lookup_widget(objet, "window_produit");
window_stock=lookup_widget(objet, "window_stock");

window_stock=create_window_stock();
gtk_widget_show(window_stock);
gtk_widget_hide(window_sorties);
gtk_widget_hide(window_produit);

}


void
on_button13_si_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget  *window_sorties; 
 GtkWidget 
*combobox3,*existe,*affiche,*non,*oui,*input10,*input11,*input12,*spinbutton3,*labelinsuffisant,*dialog_rupture;
window_sorties=lookup_widget(objet, "window_sorties");  
int quantite;

input10=lookup_widget(objet,"entry6_si"); 
combobox3=lookup_widget(objet, "combobox3_si"); 
input11=lookup_widget(objet,"entry7_si"); 
spinbutton3=lookup_widget(objet,"spinbutton6_si");
labelinsuffisant=lookup_widget(objet,"label56_si");
non=lookup_widget(objet,"label61_si");
oui=lookup_widget(objet,"label62_si");
existe=lookup_widget(objet,"label_n_existepas");
affiche=lookup_widget(objet,"affiche_rupture");
strcpy(p.exemple,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));

strcpy(p.aliment,gtk_entry_get_text(GTK_ENTRY(input10)));
p.quantite=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbutton3));
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input11)));

char id[50];
int val=0;
FILE *f3;
FILE *f2;
FILE *f;
stock c;
f3=fopen("rupture.txt","a+");
f2=fopen("produit sorties.txt","a+");
f=fopen("produit.txt","r");

 while (fscanf(f,"%s %s %s %d %s %s \n ",c.exemple,c.aliment,c.id,&(c.quantite),c.prix,c.importe)!=EOF){


 

  

 if  ( (strcmp(c.exemple,p.exemple)==0) && (strcmp(c.id,p.id)==0)){ 

       


        if ( (c.quantite>p.quantite)){
             gtk_widget_hide(affiche);
fprintf(f2,"%s %s \n",p.aliment,p.id);
 gtk_widget_hide (labelinsuffisant);
 gtk_widget_hide (non);
}



          else if ( (c.quantite==p.quantite)   )

{

	    gtk_widget_show (non);
             gtk_widget_show(affiche);
            gtk_widget_hide (labelinsuffisant);
fprintf(f2,"%s %s \n",p.aliment,p.id);
fprintf(f3,"%s %s %d \n",p.aliment,p.id,p.quantite);

}
      else if  ((c.quantite)<(p.quantite))
{
             gtk_widget_hide(affiche);
gtk_widget_show (labelinsuffisant);
 gtk_widget_hide (non);


}
    

fclose(f);

fclose(f3); 
fclose(f2);
}}
}


void
on_button12_si_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{


GtkWidget  *window_produit;
GtkWidget  *window_stock;
window_produit=create_window_produit();
window_stock=create_window_stock();
gtk_widget_show(window_stock);
}

