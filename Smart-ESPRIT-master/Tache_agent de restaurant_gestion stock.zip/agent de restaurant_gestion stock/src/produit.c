
#include "produit.h"




enum
{
EEXEMPLE,
EALIMENT,
EID,
EQUANTITE,
EPRIX,
EIMPORTE,
COLUMNS,
};
enum 
{
EALIMENTS,
EIDE,
EQUANTITEE,
COLUMN,
};


void ajout_siwar(stock p)

{
stock c;

FILE *f;

f=fopen("produit.txt","a+");
if(f!=NULL){

fprintf(f," %s %s %s %d %s %s \n",p.exemple,p.aliment,p.id,p.quantite,p.prix,p.importe);

fclose (f);
}
}
//////supprimer////
void supprimer_siwar(char id[50])
{

char aliment[50];
FILE*f=NULL;

FILE*f1=NULL;
 stock p;

f=fopen("produit.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %s %d %s %s \n " ,p.exemple,p.aliment,p.id,&(p.quantite),p.prix,p.importe)!=EOF)
{

if((strcmp(aliment,p.aliment)!=0) && strcmp(id,p.id)!=0)
{
fprintf(f1,"%s %s %s %d %s %s \n",p.exemple,p.aliment,p.id,p.quantite,p.prix,p.importe);
}

 }

fclose(f);
fclose(f1);

remove("produit.txt");
rename("ancien.txt","produit.txt");

}









void afficher_siwar (GtkWidget *liste)

{
FILE *f,*g;
char exemple [20];
char aliment [20];
char id [20];
int quantite;
char prix [20];
char importe[20];
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
if (store==NULL){

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("exemple",renderer,"text",EEXEMPLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("aliment",renderer,"text",EALIMENT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("importe",renderer,"text",EIMPORTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);}

store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("produit.txt","r");
if (f==NULL)
{
return;}
else{


f=fopen("produit.txt","a+");
while (fscanf(f,"%s %s %s %d %s %s",exemple,aliment,id,&(quantite),prix,importe)!=EOF)
{
    gtk_list_store_append (store,&iter);
     gtk_list_store_set (store,&iter,EEXEMPLE,exemple,EALIMENT,aliment,EID,id,EQUANTITE,quantite,EPRIX,prix,EIMPORTE,importe,-1);
}
fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}}






/////rechercher
void rech_produit ( char produit_rech[1000], GtkWidget *liste)

{
stock p;
FILE *f,*g;
char exemple [20];
char aliment [20];
char id [20];
int quantite;
char prix [20];
char importe[20];
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
if (store==NULL){

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("exemple",renderer,"text",EEXEMPLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("aliment",renderer,"text",EALIMENT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("importe",renderer,"text",EIMPORTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);}

store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("produit.txt","r");
if (f==NULL)
{
return;}
else{


f=fopen("produit.txt","a+");
while (fscanf(f,"%s %s %s %d %s %s",exemple,aliment,id,&(quantite),prix,importe)!=EOF)

{

if (strstr(aliment,produit_rech)!=NULL||strstr(id,produit_rech)!=NULL||strstr(prix,produit_rech)!=NULL ){
    gtk_list_store_append (store,&iter);
     gtk_list_store_set (store,&iter,EEXEMPLE,exemple,EALIMENT,aliment,EID,id,EQUANTITE,quantite,EPRIX,prix,EIMPORTE,importe,-1);
}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);}}





///////modifier_siwar
void modifier_siwar(stock c) 
{

FILE*f;
FILE*f1;
//char ch1[50],//
 stock p;

f=fopen("produit.txt","r");
f1=fopen("ancien.txt","w+");
if (f==NULL)
{printf("impo");}
else
{
while (fscanf(f,"%s %s %s %d %s %s \n ",p.exemple,p.aliment,p.id,&(p.quantite),p.prix,p.importe)!=EOF){

if( (strcmp(p.aliment,c.aliment)==0) )

fprintf(f1,"%s %s %s %d %s %s \n ",p.exemple,p.aliment,c.id,c.quantite,c.prix,c.importe);
else
fprintf(f1,"%s %s %s %d %s %s \n ",p.exemple,p.aliment,p.id,p.quantite,p.prix,p.importe);
}}
fclose(f);
fclose(f1);

remove("produit.txt");
rename("ancien.txt","produit.txt");

}
 


/////exist 
int exist_reference(char *id)
{
FILE*f=NULL;
 stock p;
f=fopen("produit.txt","r");

while (fscanf(f,"%s %s %s %d %s %s \n " ,p.exemple,p.aliment,p.id,&(p.quantite),p.prix,p.importe)!=EOF)
{
if(strcmp(p.id,id)==0)return 1;
}
fclose(f);
return 0;
}


/////exist 
int exist1_reference(char *id )
{
FILE*f=NULL;
 stock c;
f=fopen("produit.txt","r");

{
if(strcmp(c.id,id)!=0)return 1;
}
fclose(f);
return 0;

}

void afficher_enfaiedh(GtkWidget *liste)

{
FILE *f4;
char exemple [20];

char aliment [20];
char id [20];
int quantite;
char prix [20];
char importe [20];

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
if (store==NULL){



renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("aliment",renderer,"text",EALIMENTS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EIDE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUANTITEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



store=gtk_list_store_new (COLUMN,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_INT);
f4=fopen("rupture.txt","r");
if (f4==NULL)
{
return;}
else{


f4=fopen("rupture.txt","a+");
while (fscanf(f4,"%s %s %d ",aliment,id,&(quantite))!=EOF)
{

    gtk_list_store_append (store,&iter);
     gtk_list_store_set (store,&iter,EALIMENTS,aliment,EIDE,id,EQUANTITEE,quantite,-1);
}
fclose(f4);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}}}





















