#include <gtk/gtk.h>





void
on_boutonAjouter_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobuttonPd_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDIN_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDEJ_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonModifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonMmenu_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonMj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAutre_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAfficher_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonRecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonOk_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAff_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAff_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonshow_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourchoix_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourmodif_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourMeilleur_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
