#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"nutrisionniste.h"

int x;
int y;
char id2[10];


 


void
on_boutonAjouter_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f=NULL;
GtkWidget *ID;
GtkWidget *Al;
GtkWidget *Affichage;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
Menu menu;

char type[100]="PD";

int jour1;
int mois1;
int annee1;
char id1[20];
char al1[20];

if (x==1)
strcpy(type,"PD");
else
if (x==2)
strcpy(type,"Dej");
else 
if (x==3)
strcpy(type,"Din");

jour=lookup_widget(objet_graphique,"jour");
mois=lookup_widget(objet_graphique,"mois");
annee=lookup_widget(objet_graphique,"annee");

ID=lookup_widget(objet_graphique,"entryID");
Al=lookup_widget(objet_graphique,"entryAl");

strcpy(id1,gtk_entry_get_text(GTK_ENTRY(ID)));
strcpy(al1,gtk_entry_get_text(GTK_ENTRY(Al)));

menu.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
menu.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
menu.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

f=fopen("menu.txt","a+");

fprintf(f,"%s %d %d %d %s %s \n",id1,menu.date.jour,menu.date.mois,menu.date.annee,al1,type);
fclose(f);


}




void
on_radiobuttonPd_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=1;}
 
}


void
on_radiobuttonDIN_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=3;}
}


void
on_radiobuttonDEJ_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=2;}
}


void
on_buttonMmenu_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Meilleur_menu;
GtkWidget *Choix;

Choix=lookup_widget(objet_graphique,"Choix");
  gtk_widget_destroy (Choix);
Meilleur_menu=lookup_widget(objet_graphique,"Meilleur_menu");
 Meilleur_menu = create_Meilleur_menu ();
  gtk_widget_show (Meilleur_menu);
}


void
on_buttonMj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Menu_du_jour;
GtkWidget *Choix;
Choix=lookup_widget(objet_graphique,"Choix");
  gtk_widget_destroy (Choix);
Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
 Menu_du_jour = create_Menu_du_jour ();
  gtk_widget_show (Menu_du_jour);
}


void
on_buttonAj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
}


void
on_buttonAutre_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Autrechoix;
GtkWidget *Menu_du_jour;
Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
  gtk_widget_destroy (Menu_du_jour);
Autrechoix=lookup_widget(objet_graphique,"Autrechoix");
Autrechoix = create_Autrechoix ();
  gtk_widget_show (Autrechoix);
}


void
on_buttonAfficher_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Affichage;
GtkWidget *Menu_du_jour;

Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
  gtk_widget_destroy (Menu_du_jour);
Affichage=lookup_widget(objet_graphique,"Affichage");
Affichage = create_Affichage ();
gtk_widget_show (Affichage);

}


void
on_buttonSupprimer_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f;
FILE* f2;
Menu menu;
GtkWidget *id;
char id1[10];
f=fopen("menu.txt","r");
f2=fopen("tmp.txt","a+");
id=lookup_widget(objet_graphique,"entryIdet");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
if (f==NULL)
       return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id1,menu.id)!=0)
                   fprintf(f2,"%s %d %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
        }
    }
    fclose(f);
    fclose(f2);
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}


void
on_buttonModifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 FILE* f ;
 
Menu menu;

GtkWidget *id;
GtkWidget *Autre_choix;
GtkWidget *Menu_du_jour;
GtkWidget *Modif;
id=lookup_widget(objet_graphique,"entryIdet");

strcpy(id2,gtk_entry_get_text(GTK_ENTRY(id)));
    f=fopen("menu.txt","r");

        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id2,menu.id)==0)
                {
		  Autre_choix = lookup_widget(objet_graphique,"Autrechoix");
                   gtk_widget_destroy (Autre_choix); 
		Modif=lookup_widget(objet_graphique,"Modif");		  
		 Modif = create_Modif ();
                   gtk_widget_show (Modif);   
		   
		}
		else
                   {  Autre_choix=lookup_widget(objet_graphique,"Autre_choix");
                   gtk_widget_destroy (Autre_choix); 
		Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
		Menu_du_jour = create_Menu_du_jour ();
                    gtk_widget_show (Menu_du_jour);
		 
}	    
        }
    
    fclose(f);
}


void
on_buttonRecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f ;
Menu menu;
GtkWidget *id;
GtkWidget *output;
char id1[10];
char texte1[20];
 int rech=0;

id=lookup_widget(objet_graphique,"entryIdet");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
    f=fopen("menu.txt","r");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id1,menu.id)==0)
		{
		        sprintf(texte1," aliment: %s\n",menu.aliment);
		        
                        output=lookup_widget(objet_graphique,"labelidet");
                        gtk_label_set_text(GTK_LABEL(output),texte1);
                        
			rech=1;
		}
        }
}
fclose(f);
    if (rech==0)
printf("Impossible de trouver ce menu");    

}


void
on_buttonOk_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f;
FILE* f2;
GtkWidget *ID;
GtkWidget *id;
GtkWidget *Al;
GtkWidget *Affichage;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
Menu menu;

char type[10]="PD";
int jour1;
int mois1;
int annee1;

char al1[10];

if (y==1)
strcpy(type,"PD");
else
if (y==2)
strcpy(type,"Dej");
else 
if (y==3)
strcpy(type,"Din");


jour=lookup_widget(objet_graphique,"jour1");
mois=lookup_widget(objet_graphique,"mois1");
annee=lookup_widget(objet_graphique,"annee1");


Al=lookup_widget(objet_graphique,"entryalim");


strcpy(al1,gtk_entry_get_text(GTK_ENTRY(Al)));

menu.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
menu.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
menu.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

f=fopen("menu.txt","r");
f2=fopen("tmp.txt","a+");
while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
{
if (strcmp(id2,menu.id)!=0)
{
fprintf(f2,"%s %d %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
} 
else 
{
fprintf(f2,"%s %d %d %d %s %s \n",id2,menu.date.jour,menu.date.mois,menu.date.annee,al1,type);
}
}
    fclose(f2);
    fclose(f);
    
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}


void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=3;}
}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}





void
on_buttonAff_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *label_meilleur;
label_meilleur = lookup_widget(objet_graphique, "Dejeu") ;


FILE* f;
Dechet d;
char ch[20];
char message[70];
int min=100;
char jour[30];



f=fopen("dechets.txt","r+");
if(f!=NULL)
{
while (fscanf(f,"%s %d %d\n",d.jour,&d.dejeuner,&d.dinner)!=EOF)
{
if (min >= d.dejeuner )
{
min = d.dejeuner;
strcpy(ch,"dejeuner");
strcpy(jour,d.jour);
}

if (min >= d.dinner)
{
min = d.dinner ;
strcpy(ch,"Dinner");
strcpy(jour,d.jour);
}

}
fclose(f);
sprintf(message,"Le meilleur menu est le : %s de %s",ch,jour);
gtk_label_set_text(GTK_LABEL(label_meilleur),message);
}

}





void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *id;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* aliment;
	gchar* type;
	Menu menu;
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&jour,2,&mois,3,&annee,4,&aliment,5,&type,6,-1);
strcpy(menu.id,id);
strcpy(menu.date.jour,jour);
strcpy(menu.date.mois,mois);
strcpy(menu.date.annee,annee);
strcpy(menu.date.annee,annee);
strcpy(menu.aliment,aliment);
strcpy(menu.type,type);


Afficher(treeview,"menu.txt");
}
}


void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Menu_du_jour;
GtkWidget *Affichage;

Affichage=lookup_widget(objet_graphique,"Affichage");
gtk_widget_destroy(Affichage);
Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
 Menu_du_jour = create_Menu_du_jour ();
  gtk_widget_show (Menu_du_jour);
}


void
on_buttonshow_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Affichage;
GtkWidget *treeview1;
Menu menu;

Affichage = lookup_widget(objet_graphique,"buttonshow");
treeview1=lookup_widget(Affichage,"treeview1");

Afficher(treeview1,"menu.txt");
}


void
on_buttonretourchoix_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *choix;
GtkWidget *Menu_du_jour;

 Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
  gtk_widget_destroy (Menu_du_jour);
choix=lookup_widget(objet_graphique,"Choix");	
choix = create_Choix ();
  gtk_widget_show (choix);
}


void
on_buttonretourmodif_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Autre_choix;
GtkWidget *Modif;

Modif=lookup_widget(objet_graphique,"Modif");
gtk_widget_destroy (Modif); 
Autre_choix=lookup_widget(objet_graphique,"Autre_choix");
Autre_choix = create_Autrechoix ();
  gtk_widget_show (Autre_choix);
 
}


void
on_buttonretourMeilleur_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Meilleur_menu;
GtkWidget *Choix;

Meilleur_menu=lookup_widget(objet_graphique,"Meilleur_menu");
  gtk_widget_show (Meilleur_menu);
Choix=lookup_widget(objet_graphique,"Choix");	
Choix = create_Choix ();
  gtk_widget_show (Choix);
}

