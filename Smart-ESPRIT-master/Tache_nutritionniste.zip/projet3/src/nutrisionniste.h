#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}Date;
typedef struct
{
char id[10];
Date date;
char aliment[10];
char type[10];
}Menu;

typedef struct
{
char jour[20];
int dejeuner;
int dinner;
}Dechet;

void Ajouter(Menu menu);
void Supprimer(char id[10],Menu menu);
void Afficher(GtkWidget *liste,char ch[50]);
void Chercher(char id[10],Menu menu);
void Modifier(char id[10],Menu menu);

